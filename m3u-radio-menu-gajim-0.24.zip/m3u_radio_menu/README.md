# M3U Radio Menu v0.18

Changes in this build:

- added a dynamic light-column meter to the separate M3U tray icon;
- when playback uses GStreamer, the meter follows the real audio level through the GStreamer `level` element;
- when playback falls back to an external player, the tray icon shows a small activity pulse instead of a real signal meter;
- diagnostics now show playback backend, GStreamer meter availability, and the last normalized audio level;
- kept v0.17 controller/title/now-playing behavior.
