from __future__ import annotations

import inspect
import math
import logging
import shutil
import subprocess
import urllib.request
from dataclasses import dataclass
from functools import partial
from threading import Thread
from typing import Any, Callable, Optional

from gi.repository import Gio, GLib, Gtk, Pango
try:
    from gi.repository import Gst
except Exception:
    Gst = None

from gajim.common import app
from gajim.plugins import GajimPlugin
from gajim.plugins.plugins_i18n import _

from .config_dialog import M3URadioMenuConfigDialog

log = logging.getLogger('gajim.p.m3u_radio_menu')
DEFAULT_NAME = 'Balearic Grooves'
DEFAULT_PLAYLIST_URL = 'https://listen.openstream.co/6780.m3u'
DEFAULT_PLAYLISTS_TEXT = f'{DEFAULT_NAME} | {DEFAULT_PLAYLIST_URL}'
ACTION_NAME = 'm3u-radio-toggle'
ACTION_DETAILED = f'app.{ACTION_NAME}'
USER_AGENT = 'Gajim M3U Radio Menu/0.24'


@dataclass
class PlaylistEntry:
    name: str
    url: str


class RadioPlayer:
    def __init__(
        self,
        on_metadata: Callable[[str], None] | None = None,
        on_level: Callable[[Any, Any], None] | None = None,
    ) -> None:
        self._gst_player = None
        self._gst_bus = None
        self._gst_level_supported = False
        self._gst_spectrum_supported = False
        self._meter_focus = 'lowmid'
        self._meter_update_interval_ms = 80
        self._process: Optional[subprocess.Popen[str]] = None
        self._on_metadata = on_metadata
        self._on_level = on_level
        if Gst is not None:
            try:
                Gst.init(None)
            except Exception:
                log.exception('Could not initialize GStreamer')

    @property
    def is_playing(self) -> bool:
        if self._gst_player is not None:
            return True
        return self._process is not None and self._process.poll() is None

    @property
    def backend_name(self) -> str:
        if self._gst_player is not None:
            return 'GStreamer'
        if self._process is not None and self._process.poll() is None:
            return 'external player'
        return 'none'

    @property
    def has_audio_level(self) -> bool:
        return self._gst_player is not None and (self._gst_spectrum_supported or self._gst_level_supported)

    @property
    def has_frequency_meter(self) -> bool:
        return self._gst_player is not None and self._gst_spectrum_supported

    @property
    def meter_focus(self) -> str:
        return self._meter_focus

    @property
    def meter_update_interval_ms(self) -> int:
        return self._meter_update_interval_ms

    def set_meter_options(self, focus: str, update_interval_ms: int) -> None:
        if focus not in ('bass', 'lowmid', 'full'):
            focus = 'lowmid'
        self._meter_focus = focus
        self._meter_update_interval_ms = max(50, min(1000, int(update_interval_ms)))

    def play(self, playlist_url: str) -> str:
        self.stop()
        stream_url = self._resolve(playlist_url)
        if Gst is not None:
            try:
                player = Gst.ElementFactory.make('playbin', 'm3u-radio-playbin')
                if player is not None:
                    player.set_property('uri', stream_url)
                    self._gst_level_supported = False
                    self._gst_spectrum_supported = False
                    analysis_filter = self._build_audio_analysis_filter()
                    if analysis_filter is not None:
                        try:
                            player.set_property('audio-filter', analysis_filter)
                        except Exception:
                            self._gst_level_supported = False
                            self._gst_spectrum_supported = False
                            log.debug('Could not attach GStreamer analysis filter', exc_info=True)
                    bus = player.get_bus()
                    if bus is not None:
                        bus.add_signal_watch()
                        bus.connect('message::tag', self._on_gst_tag)
                        bus.connect('message::error', self._on_gst_error)
                        bus.connect('message::eos', self._on_gst_eos)
                        bus.connect('message::element', self._on_gst_element)
                        self._gst_bus = bus
                    player.set_state(Gst.State.PLAYING)
                    self._gst_player = player
                    return stream_url
            except Exception:
                log.exception('GStreamer failed, trying external player')
                self._gst_player = None
                self._gst_bus = None
                self._gst_level_supported = False
                self._gst_spectrum_supported = False
        command = self._find_external_player()
        if command is None:
            raise RuntimeError('No playback backend found. Install GStreamer, mpv, vlc, cvlc, or ffplay.')
        args = [command, '-nodisp', '-autoexit', stream_url] if command == 'ffplay' else [command, stream_url]
        self._process = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)
        return stream_url

    def stop(self) -> None:
        if self._gst_player is not None:
            try:
                self._gst_player.set_state(Gst.State.NULL)
            except Exception:
                log.exception('Could not stop GStreamer player')
            self._gst_player = None
            self._gst_level_supported = False
            self._gst_spectrum_supported = False
            self._emit_level(0.0, -60.0)
        if self._gst_bus is not None:
            try:
                self._gst_bus.remove_signal_watch()
            except Exception:
                pass
            self._gst_bus = None
        if self._process is not None:
            try:
                if self._process.poll() is None:
                    self._process.terminate()
                    try:
                        self._process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        self._process.kill()
            finally:
                self._process = None
            self._emit_level(0.0, -60.0)

    def _build_audio_analysis_filter(self) -> Any | None:
        if Gst is None:
            return None
        try:
            analysis_bin = Gst.Bin.new('m3u-radio-analysis')
            if analysis_bin is None:
                return None

            elements = []

            spectrum = Gst.ElementFactory.make('spectrum', 'm3u-radio-spectrum')
            if spectrum is not None:
                try:
                    spectrum.set_property('interval', self._meter_update_interval_ms * 1000000)
                    spectrum.set_property('bands', 64)
                    spectrum.set_property('threshold', -80)
                    spectrum.set_property('post-messages', True)
                    if spectrum.find_property('message-magnitude') is not None:
                        spectrum.set_property('message-magnitude', True)
                    if spectrum.find_property('message-phase') is not None:
                        spectrum.set_property('message-phase', False)
                    elements.append(spectrum)
                    self._gst_spectrum_supported = True
                except Exception:
                    self._gst_spectrum_supported = False
                    log.debug('Could not configure GStreamer spectrum analyzer', exc_info=True)

            level = Gst.ElementFactory.make('level', 'm3u-radio-level')
            if level is not None:
                try:
                    level.set_property('interval', self._meter_update_interval_ms * 1000000)
                    level.set_property('message', True)
                    elements.append(level)
                    self._gst_level_supported = True
                except Exception:
                    self._gst_level_supported = False
                    log.debug('Could not configure GStreamer level meter', exc_info=True)

            if not elements:
                return None

            for element in elements:
                analysis_bin.add(element)

            for previous, current in zip(elements, elements[1:]):
                if not previous.link(current):
                    log.debug('Could not link %s -> %s in analysis bin', previous.name, current.name)
                    return elements[0]

            sink_pad = elements[0].get_static_pad('sink')
            src_pad = elements[-1].get_static_pad('src')
            if sink_pad is None or src_pad is None:
                return elements[0]

            analysis_bin.add_pad(Gst.GhostPad.new('sink', sink_pad))
            analysis_bin.add_pad(Gst.GhostPad.new('src', src_pad))
            return analysis_bin
        except Exception:
            self._gst_level_supported = False
            self._gst_spectrum_supported = False
            log.debug('Could not build GStreamer analysis filter', exc_info=True)
            return None

    def _spectrum_three_band_dbs(self, values: Any) -> list[float] | None:
        try:
            db_values = [float(value) for value in values]
        except Exception:
            return None
        if not db_values:
            return None

        def band_db(start: int, end: int) -> float:
            subset = db_values[start:min(end, len(db_values))]
            if not subset:
                return -80.0
            powers = []
            for value in subset:
                db = max(-80.0, min(0.0, float(value)))
                powers.append(math.pow(10.0, db / 10.0))
            average_power = sum(powers) / max(1, len(powers))
            peak_db = max(subset)
            average_db = 10.0 * math.log10(max(average_power, 1.0e-12))
            # Keep movement lively in a 16x16 tray icon: use a mostly-average
            # dB value, but allow transients to lift the bar a little.
            return max(average_db, peak_db - 8.0)

        total = len(db_values)
        # GStreamer spectrum bands are linear across the available audio range.
        # These ranges are intentionally simple and visual rather than a studio
        # analyzer: bass, mid and treble as three adjacent tray bars.
        bass_end = max(3, min(total, 6))
        mid_end = max(bass_end + 1, min(total, 22))
        return [
            band_db(0, bass_end),
            band_db(bass_end, mid_end),
            band_db(mid_end, total),
        ]

    def _on_gst_tag(self, _bus: Any, message: Any) -> None:
        if self._on_metadata is None or Gst is None:
            return
        try:
            tags = message.parse_tag()
            title = self._tag_string(tags, Gst.TAG_TITLE)
            artist = self._tag_string(tags, Gst.TAG_ARTIST) or self._tag_string(tags, Gst.TAG_ALBUM_ARTIST)
            organization = self._tag_string(tags, Gst.TAG_ORGANIZATION)
            parts = []
            if artist:
                parts.append(artist)
            if title:
                parts.append(title)
            if not parts and organization:
                parts.append(organization)
            if parts:
                text = ' — '.join(parts)
                GLib.idle_add(self._on_metadata, text)
        except Exception:
            log.debug('Could not parse GStreamer tag message', exc_info=True)

    def _on_gst_element(self, _bus: Any, message: Any) -> None:
        if self._on_level is None:
            return
        try:
            structure = message.get_structure()
            if structure is None:
                return

            name = structure.get_name()
            if name == 'spectrum' and self._gst_spectrum_supported:
                try:
                    magnitudes = structure.get_value('magnitude')
                except Exception:
                    magnitudes = None
                if not magnitudes:
                    return
                dbs = self._spectrum_three_band_dbs(magnitudes)
                if dbs is None:
                    return
                normalized = [self._normalize_db_for_meter(db) for db in dbs]
                GLib.idle_add(self._emit_level, normalized, dbs)
                return

            if name != 'level' or self._gst_spectrum_supported:
                return

            # Fallback: use full-band RMS if spectrum messages are unavailable.
            values = None
            try:
                values = structure.get_value('rms')
            except Exception:
                values = None
            if not values:
                try:
                    values = structure.get_value('peak')
                except Exception:
                    values = None
            if not values:
                return

            db_values = []
            for value in values:
                try:
                    db_values.append(float(value))
                except Exception:
                    pass
            if not db_values:
                return

            db = max(db_values)
            normalized = self._normalize_db_for_meter(db)
            GLib.idle_add(self._emit_level, [normalized, normalized, normalized], [db, db, db])
        except Exception:
            log.debug('Could not parse GStreamer analysis message', exc_info=True)

    @staticmethod
    def _normalize_db_for_meter(db: float) -> float:
        # Audio meters are conventionally expressed in decibels, i.e. on a
        # logarithmic scale. Keep the display on a dB scale instead of treating
        # the value as a simple linear 0..1 number.
        floor_db = -55.0
        clipped = max(floor_db, min(0.0, float(db)))
        return (clipped - floor_db) / abs(floor_db)

    def _emit_level(self, level: Any, db: Any = -60.0) -> bool:
        if self._on_level is not None:
            try:
                self._on_level(level, db)
            except Exception:
                log.debug('Could not emit audio level', exc_info=True)
        return False

    def _on_gst_error(self, _bus: Any, message: Any) -> None:
        try:
            error, debug = message.parse_error()
            log.warning('GStreamer radio error: %s %s', error, debug)
        except Exception:
            pass

    def _on_gst_eos(self, *_args: Any) -> None:
        log.debug('GStreamer radio stream reached EOS')

    @staticmethod
    def _tag_string(tags: Any, tag: str) -> str:
        try:
            ok, value = tags.get_string(tag)
            return str(value) if ok and value else ''
        except Exception:
            return ''

    def _resolve(self, url: str) -> str:
        lowered = url.lower().split('?', 1)[0]
        if not lowered.endswith(('.m3u', '.m3u8', '.pls')):
            return url
        request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(request, timeout=10) as response:
            text = response.read(128 * 1024).decode('utf-8', errors='replace')
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if line.lower().startswith('file') and '=' in line:
                line = line.split('=', 1)[1].strip()
            if line.startswith(('http://', 'https://')):
                return line
        raise RuntimeError('The playlist did not contain an HTTP/HTTPS stream URL.')

    @staticmethod
    def _find_external_player() -> Optional[str]:
        for candidate in ('mpv', 'vlc', 'cvlc', 'ffplay'):
            if shutil.which(candidate):
                return candidate
        return None


class M3URadioMenuPlugin(GajimPlugin):
    def init(self) -> None:
        self.description = _('Adds sidebar/tray controls to toggle M3U radio streams.')
        self.config_dialog = partial(M3URadioMenuConfigDialog, self)
        self.config_default_values = {
            'display_name': (DEFAULT_NAME, ''),
            'playlist_url': (DEFAULT_PLAYLIST_URL, ''),
            'playlists_text': (DEFAULT_PLAYLISTS_TEXT, ''),
            'current_playlist_index': (0, ''),
            'show_controller_on_enable': (True, ''),
            'create_own_tray_icon': (True, ''),
            'try_gajim_tray_menu': (True, ''),
            'try_roster_button': (True, ''),
            'show_now_playing': (True, ''),
            'publish_now_playing_status': (False, ''),
            'restore_status_on_stop': (True, ''),
            'status_scroll_width': ('64', ''),
            'status_scroll_interval': ('6', ''),
            'meter_focus': ('lowmid', ''),
            'meter_sensitivity': ('1.6', ''),
            'meter_update_interval_ms': ('80', ''),
        }
        self._player = RadioPlayer(self._on_metadata, self._on_audio_level)
        self._action = None
        self._controller_window = None
        self._status_label = None
        self._toggle_button = None
        self._details_label = None
        self._station_label = None
        self._now_playing_label = None
        self._copy_song_button = None
        self._own_tray_icon = None
        self._own_tray_thread = None
        self._tray_meter_source = None
        self._tray_meter_frame = 0
        self._audio_level = 0.0
        self._audio_level_db = -60.0
        self._audio_levels = [0.0, 0.0, 0.0]
        self._audio_level_dbs = [-60.0, -60.0, -60.0]
        self._native_pystray_patch = None
        self._last_install_details = ''
        self._roster_widget = None
        self._roster_widget_parent = None
        self._roster_play_button = None
        self._roster_station_label = None
        self._roster_track_label = None
        self._roster_label = None
        self._roster_icon = None
        self._roster_copy_song_button = None
        self._roster_menu_button = None
        self._roster_popover = None
        self._settings_window = None
        self._settings_text_view = None
        self._metadata_text = ''
        self._marquee_offset = 0
        self._marquee_source = None
        self._status_scroll_source = None
        self._status_scroll_offset = 0
        self._last_published_status = ''
        self._previous_status_message = None
        self._previous_status_show = None
        self._main_window_title_original = None

    def activate(self) -> None:
        GLib.idle_add(self._install)

    def deactivate(self) -> None:
        self._stop_status_scroll(restore=True)
        self._stop_marquee()
        self._restore_window_titles()
        self._player.stop()
        self._stop_tray_meter()
        self._remove_own_tray_icon()
        self._restore_native_pystray_menu()
        self._remove_roster_button()
        self._remove_controller_window()
        self._remove_settings_window()
        self._remove_action()

    def refresh_ui(self) -> None:
        self._apply_meter_settings()
        self._remove_roster_button()
        if self.config['try_roster_button']:
            self._install_roster_button()
        self._restore_native_pystray_menu()
        inserted = self._try_patch_gajim_pystray_menu() if self.config['try_gajim_tray_menu'] else False
        if not inserted and self.config['create_own_tray_icon']:
            self._install_own_tray_icon()
        self._refresh_labels()
        self._refresh_native_pystray_menu()
        self._refresh_own_tray_menu()
        self._refresh_roster_button()

    def _install(self) -> bool:
        self._apply_meter_settings()
        self._install_action()
        if self.config['try_roster_button']:
            self._install_roster_button()
        inserted = self._try_patch_gajim_pystray_menu() if self.config['try_gajim_tray_menu'] else False
        if not inserted and self.config['create_own_tray_icon']:
            self._install_own_tray_icon()
        if self.config['show_controller_on_enable']:
            self._show_controller_window(self._last_install_details or _('Ready'))
        return False

    def _meter_focus_value(self) -> str:
        value = str(self.config['meter_focus']).strip().lower()
        return value if value in ('bass', 'lowmid', 'full') else 'lowmid'

    def _meter_sensitivity_value(self) -> float:
        try:
            value = float(str(self.config['meter_sensitivity']).replace(',', '.'))
        except Exception:
            value = 1.6
        return max(0.2, min(5.0, value))

    def _meter_update_interval_value(self) -> int:
        try:
            value = int(float(str(self.config['meter_update_interval_ms']).replace(',', '.')))
        except Exception:
            value = 80
        return max(50, min(1000, value))

    def _apply_meter_settings(self) -> None:
        self._player.set_meter_options(self._meter_focus_value(), self._meter_update_interval_value())

    def _install_action(self) -> None:
        self._remove_action()
        gio_app = self._get_gio_application()
        if gio_app is None:
            self._last_install_details = 'No Gio.Application object found.'
            return
        action = Gio.SimpleAction.new(ACTION_NAME, None)
        action.connect('activate', lambda *_args: self._toggle_playback())
        gio_app.add_action(action)
        self._action = action
        try:
            gio_app.set_accels_for_action(ACTION_DETAILED, ['<Primary><Alt>r'])
        except Exception:
            log.debug('Could not set accelerator', exc_info=True)

    def _remove_action(self) -> None:
        gio_app = self._get_gio_application()
        if gio_app is not None:
            try:
                gio_app.remove_action(ACTION_NAME)
            except Exception:
                pass
        self._action = None

    def _toggle_playback(self) -> None:
        if self._player.is_playing:
            self._stop_status_scroll(restore=True)
            self._player.stop()
            self._metadata_text = ''
            self._set_status(_('Stopped'))
        else:
            try:
                self._apply_meter_settings()
                self._apply_meter_settings()
                entry = self._current_playlist()
                stream = self._player.play(entry.url)
                self._metadata_text = ''
                self._capture_previous_status()
                self._start_status_scroll()
                self._set_status(_('Playing: %s') % stream)
            except Exception as error:
                log.exception('Could not start radio')
                self._set_status(_('Error: %s') % error)
        self._refresh_everything()

    def _select_playlist(self, index: int, start_playing: bool | None = None) -> None:
        entries = self._playlist_entries()
        if not entries:
            return
        index = max(0, min(index, len(entries) - 1))
        was_playing = self._player.is_playing
        self.config['current_playlist_index'] = index
        self._metadata_text = ''
        if was_playing or start_playing:
            self._stop_status_scroll(restore=False)
            self._player.stop()
            try:
                self._apply_meter_settings()
                entry = self._current_playlist()
                stream = self._player.play(entry.url)
                self._capture_previous_status()
                self._start_status_scroll()
                self._set_status(_('Playing: %s') % stream)
            except Exception as error:
                self._set_status(_('Error: %s') % error)
        else:
            self._set_status(_('Selected: %s') % entries[index].name)
        self._refresh_everything()

    def _refresh_everything(self) -> None:
        self._refresh_labels()
        self._refresh_native_pystray_menu()
        self._refresh_own_tray_menu()
        self._refresh_roster_button()
        self._refresh_window_titles()
        self._refresh_marquee()
        self._sync_tray_meter()
        if self.config['publish_now_playing_status'] and self._player.is_playing:
            self._start_status_scroll()
        elif not self.config['publish_now_playing_status']:
            self._stop_status_scroll(restore=True)

    def _on_metadata(self, text: str) -> bool:
        if text and text != self._metadata_text:
            self._metadata_text = text
            self._marquee_offset = 0
            self._refresh_everything()
            self._publish_now_playing_status_once()
        return False

    def _on_audio_level(self, level: Any, db: Any = -60.0) -> None:
        if isinstance(level, (list, tuple)):
            targets = [float(value) for value in level[:3]]
        else:
            targets = [float(level), float(level), float(level)]
        while len(targets) < 3:
            targets.append(0.0)

        if isinstance(db, (list, tuple)):
            dbs = [float(value) for value in db[:3]]
        else:
            dbs = [float(db), float(db), float(db)]
        while len(dbs) < 3:
            dbs.append(-60.0)

        sensitivity = self._meter_sensitivity_value()
        targets = [max(0.0, min(1.0, value * sensitivity)) for value in targets]

        smoothed = []
        for old_value, target in zip(self._audio_levels, targets):
            # Quick attack and slower release: lively, but readable in a tiny icon.
            if target >= old_value:
                smoothed.append((old_value * 0.25) + (target * 0.75))
            else:
                smoothed.append((old_value * 0.66) + (target * 0.34))
        self._audio_levels = smoothed
        self._audio_level_dbs = dbs
        self._audio_level = max(smoothed)
        self._audio_level_db = max(dbs)

    def _install_roster_button(self) -> bool:
        if self._roster_widget is not None:
            return True
        target = self._find_roster_insertion_target()
        if target is None:
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Roster/sidebar insertion target was not found.'
            return False
        parent, after_child = target
        try:
            root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            root.set_margin_top(4)
            root.set_margin_bottom(4)
            root.set_margin_start(4)
            root.set_margin_end(4)
            root.set_hexpand(True)

            play_button = Gtk.Button()
            play_button.add_css_class('flat')
            play_button.set_tooltip_text(_('Play/stop M3U Radio'))
            play_button.set_hexpand(True)
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
            row.set_margin_start(6)
            row.set_margin_end(6)
            icon = Gtk.Image.new_from_icon_name('media-playback-start-symbolic')
            icon.set_pixel_size(16)
            labels = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            labels.set_hexpand(True)
            station_label = Gtk.Label(label=self._display_name())
            station_label.set_xalign(0)
            station_label.set_hexpand(True)
            station_label.set_ellipsize(Pango.EllipsizeMode.END)
            track_label = Gtk.Label(label='')
            track_label.set_xalign(0)
            track_label.set_hexpand(True)
            track_label.set_ellipsize(Pango.EllipsizeMode.END)
            labels.append(station_label)
            labels.append(track_label)
            row.append(icon)
            row.append(labels)
            play_button.set_child(row)
            play_button.connect('clicked', lambda *_args: self._toggle_playback())
            root.append(play_button)

            copy_song_button = Gtk.Button()
            copy_song_button.add_css_class('flat')
            copy_song_button.set_tooltip_text(_('Copy current song title'))
            copy_song_button.set_child(Gtk.Image.new_from_icon_name('edit-copy-symbolic'))
            copy_song_button.connect('clicked', self._copy_current_song_title)
            root.append(copy_song_button)

            menu_button = Gtk.MenuButton()
            menu_button.add_css_class('flat')
            menu_button.set_tooltip_text(_('Choose playlist'))
            menu_button.set_icon_name('open-menu-symbolic')
            self._roster_popover = Gtk.Popover()
            menu_button.set_popover(self._roster_popover)
            root.append(menu_button)

            settings_button = Gtk.Button()
            settings_button.add_css_class('flat')
            settings_button.set_tooltip_text(_('M3U Radio settings'))
            settings_button.set_child(Gtk.Image.new_from_icon_name('emblem-system-symbolic'))
            settings_button.connect('clicked', lambda *_args: self._show_settings_window())
            root.append(settings_button)

            if hasattr(parent, 'insert_child_after') and after_child is not None:
                parent.insert_child_after(root, after_child)
            elif hasattr(parent, 'prepend'):
                parent.prepend(root)
            elif hasattr(parent, 'append'):
                parent.append(root)
            else:
                return False
            self._roster_widget = root
            self._roster_widget_parent = parent
            self._roster_play_button = play_button
            self._roster_station_label = station_label
            self._roster_track_label = track_label
            self._roster_label = station_label
            self._roster_icon = icon
            self._roster_copy_song_button = copy_song_button
            self._roster_menu_button = menu_button
            self._rebuild_roster_playlist_menu()
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Added a visual M3U row to the roster/sidebar area.'
            self._refresh_roster_button()
            return True
        except Exception as error:
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Could not add roster/sidebar row: %s' % error
            log.debug('Could not add roster/sidebar row', exc_info=True)
            return False

    def _find_roster_insertion_target(self) -> tuple[Any, Any | None] | None:
        root = getattr(app, 'window', None)
        if root is None:
            return None
        widgets = list(self._walk_widgets(root))
        for widget, parent in widgets:
            if self._looks_like_search_widget(widget):
                row = parent or widget
                container = self._nearest_appendable_ancestor(row, widgets)
                if container is not None:
                    return container, row
        for widget, _parent in widgets:
            cls = widget.__class__.__name__.lower()
            if isinstance(widget, Gtk.Box) and ('sidebar' in cls or 'list' in cls or 'box' in cls):
                return widget, None
        return None

    def _walk_widgets(self, root: Any) -> list[tuple[Any, Any | None]]:
        result: list[tuple[Any, Any | None]] = []
        seen: set[int] = set()

        def add(obj: Any, parent: Any | None, depth: int) -> None:
            if obj is None or id(obj) in seen or depth > 30:
                return
            seen.add(id(obj))
            if isinstance(obj, Gtk.Widget):
                result.append((obj, parent))
                try:
                    child = obj.get_first_child()
                    while child is not None:
                        add(child, obj, depth + 1)
                        child = child.get_next_sibling()
                except Exception:
                    pass
                for meth in ('get_child', 'get_content', 'get_top_bar', 'get_bottom_bar', 'get_start_child', 'get_end_child', 'get_center_widget'):
                    try:
                        fn = getattr(obj, meth, None)
                        if callable(fn):
                            add(fn(), obj, depth + 1)
                    except Exception:
                        pass

        add(root, None, 0)
        return result

    def _looks_like_search_widget(self, widget: Any) -> bool:
        cls = widget.__class__.__name__.lower()
        if 'search' in cls and isinstance(widget, Gtk.Widget):
            return True
        for attr in ('get_placeholder_text', 'get_text'):
            try:
                fn = getattr(widget, attr, None)
                if callable(fn):
                    text = fn()
                    if text and 'search' in str(text).lower():
                        return True
            except Exception:
                pass
        return False

    def _nearest_appendable_ancestor(self, widget: Any, widgets: list[tuple[Any, Any | None]]) -> Any | None:
        parent_of = {id(w): p for w, p in widgets}
        obj = widget
        for _ in range(8):
            parent = parent_of.get(id(obj))
            if parent is None:
                return None
            if hasattr(parent, 'insert_child_after') or hasattr(parent, 'append') or hasattr(parent, 'prepend'):
                return parent
            obj = parent
        return None

    def _remove_roster_button(self) -> None:
        widget = self._roster_widget
        parent = self._roster_widget_parent
        self._roster_widget = None
        self._roster_widget_parent = None
        self._roster_play_button = None
        self._roster_station_label = None
        self._roster_track_label = None
        self._roster_label = None
        self._roster_icon = None
        self._roster_copy_song_button = None
        self._roster_menu_button = None
        self._roster_popover = None
        if widget is None:
            return
        try:
            if parent is not None and hasattr(parent, 'remove'):
                parent.remove(widget)
            else:
                widget.unparent()
        except Exception:
            log.debug('Could not remove roster/sidebar row', exc_info=True)

    def _refresh_roster_button(self) -> None:
        if self._roster_widget is None:
            return
        try:
            if self._roster_icon is not None:
                self._roster_icon.set_from_icon_name('media-playback-stop-symbolic' if self._player.is_playing else 'media-playback-start-symbolic')
            if self._roster_station_label is not None:
                self._roster_station_label.set_label(self._roster_station_text())
            if self._roster_track_label is not None:
                self._roster_track_label.set_label(self._roster_track_text())
            self._rebuild_roster_playlist_menu()
        except Exception:
            pass

    def _roster_button_label(self) -> str:
        return self._roster_station_text()

    def _roster_station_text(self) -> str:
        prefix = '■ ' if self._player.is_playing else '▶ '
        return prefix + self._display_name()

    def _roster_track_text(self) -> str:
        if self.config['show_now_playing'] and self._player.is_playing and self._metadata_text:
            return self._marquee_text(self._metadata_text, 38)
        return ''

    def _rebuild_roster_playlist_menu(self) -> None:
        if self._roster_popover is None:
            return
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        box.set_margin_start(6)
        box.set_margin_end(6)
        entries = self._playlist_entries()
        current = self._current_playlist_index()
        for i, entry in enumerate(entries):
            label = ('● ' if i == current else '○ ') + entry.name
            btn = Gtk.Button(label=label)
            btn.add_css_class('flat')
            btn.connect('clicked', self._on_playlist_button_clicked, i)
            box.append(btn)
        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        box.append(sep)
        settings = Gtk.Button(label=_('Radio settings...'))
        settings.add_css_class('flat')
        settings.connect('clicked', lambda *_args: self._show_settings_window())
        box.append(settings)
        self._roster_popover.set_child(box)

    def _on_playlist_button_clicked(self, _button: Gtk.Button, index: int) -> None:
        if self._roster_popover is not None:
            self._roster_popover.popdown()
        self._select_playlist(index)

    def _try_patch_gajim_pystray_menu(self) -> bool:
        if self._native_pystray_patch is not None:
            return True
        try:
            import pystray
        except Exception as error:
            self._last_install_details = 'pystray is not importable: %s' % error
            return False
        icon = self._find_pystray_icon()
        if icon is None:
            self._last_install_details = 'Gajim systray exists, but no underlying pystray.Icon was found.'
            return False
        try:
            old_menu = getattr(icon, 'menu', None)
            if old_menu is None:
                self._last_install_details = 'Found Gajim pystray.Icon, but it has no menu.'
                return False

            def toggle(_icon=None, _item=None):
                GLib.idle_add(self._toggle_playback)

            def show_controller(_icon=None, _item=None):
                GLib.idle_add(self._show_controller_window, _('Opened from Gajim tray menu.'))

            def show_settings(_icon=None, _item=None):
                GLib.idle_add(self._show_settings_window)

            def show_diagnostics(_icon=None, _item=None):
                GLib.idle_add(self._show_diagnostics_window)

            def make_select(index: int):
                def select(_icon=None, _item=None):
                    GLib.idle_add(self._select_playlist, index)
                return select

            def items():
                result = [
                    pystray.MenuItem(lambda _item: ('Stop ' if self._player.is_playing else 'Play ') + self._display_name(), toggle, default=True),
                ]
                for i, entry in enumerate(self._playlist_entries()):
                    result.append(pystray.MenuItem(lambda _item, i=i, entry=entry: ('● ' if i == self._current_playlist_index() else '○ ') + entry.name, make_select(i)))
                result.extend([
                    pystray.MenuItem('M3U Radio settings', show_settings),
                    pystray.MenuItem('M3U Radio controller', show_controller),
                    pystray.MenuItem('M3U Radio diagnostics', show_diagnostics),
                ])
                sep = getattr(pystray.Menu, 'SEPARATOR', None)
                if sep is not None:
                    result.append(sep)
                result.extend(self._read_pystray_menu_items(old_menu))
                return tuple(result)

            icon.menu = pystray.Menu(items)
            self._native_pystray_patch = (icon, old_menu)
            self._refresh_native_pystray_menu()
            self._last_install_details = 'Added M3U Radio items to the existing Gajim tray menu.'
            return True
        except Exception as error:
            self._last_install_details = 'Could not wrap Gajim tray menu: %s' % error
            log.debug('Could not wrap Gajim tray menu', exc_info=True)
            return False

    def _read_pystray_menu_items(self, menu: Any) -> tuple[Any, ...]:
        try:
            return tuple(menu)
        except Exception:
            pass
        for attr in ('items', '_items'):
            try:
                value = getattr(menu, attr)
                if callable(value):
                    value = value()
                return tuple(value)
            except Exception:
                pass
        return ()

    def _find_pystray_icon(self) -> Any | None:
        roots = [getattr(app, 'app', None), getattr(getattr(app, 'app', None), 'systray', None), getattr(app, 'window', None), getattr(app, 'systray', None)]
        seen: set[int] = set()
        queue: list[tuple[Any, int]] = [(root, 0) for root in roots if root is not None]
        while queue:
            obj, depth = queue.pop(0)
            if id(obj) in seen:
                continue
            seen.add(id(obj))
            if self._looks_like_pystray_icon(obj):
                return obj
            if depth >= 8:
                continue
            try:
                names = dir(obj)
            except Exception:
                continue
            for name in names:
                if name.startswith('__'):
                    continue
                low = name.lower()
                if not any(token in low for token in ('tray', 'icon', 'backend', 'menu', 'pystray', 'status')):
                    continue
                try:
                    value = getattr(obj, name)
                except Exception:
                    continue
                if value is None or inspect.ismodule(value) or inspect.isclass(value) or callable(value):
                    continue
                queue.append((value, depth + 1))
        return None

    def _looks_like_pystray_icon(self, obj: Any) -> bool:
        module = getattr(obj.__class__, '__module__', '')
        name = getattr(obj.__class__, '__name__', '')
        return (module.startswith('pystray') and name == 'Icon') or (
            'pystray' in module.lower() and hasattr(obj, 'menu') and hasattr(obj, 'update_menu')
        )

    def _refresh_native_pystray_menu(self) -> None:
        if self._native_pystray_patch is None:
            return
        icon, _old_menu = self._native_pystray_patch
        try:
            icon.update_menu()
        except Exception:
            log.debug('Could not refresh Gajim pystray menu', exc_info=True)

    def _restore_native_pystray_menu(self) -> None:
        if self._native_pystray_patch is None:
            return
        icon, old_menu = self._native_pystray_patch
        self._native_pystray_patch = None
        try:
            icon.menu = old_menu
            icon.update_menu()
        except Exception:
            log.debug('Could not restore Gajim pystray menu', exc_info=True)

    def _make_tray_icon_image(self) -> Any:
        from PIL import Image, ImageDraw

        image = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        playing = self._player.is_playing

        if self._player.has_audio_level:
            levels = [max(0.0, min(1.0, value)) for value in self._audio_levels]
        else:
            # External-player fallback: no real spectrum data is available.
            pulse = 0.18 + 0.08 * (self._tray_meter_frame % 4)
            levels = [pulse, max(0.12, pulse * 0.75), max(0.10, pulse * 0.55)]

        segments = 9
        columns = [(9, 22), (26, 39), (43, 56)]
        y_bottom = 58
        segment_h = 4
        gap = 2
        for column_index, (x0, x1) in enumerate(columns):
            level = levels[column_index] if playing else 0.0
            lit_segments = max(1, min(segments, int(round(level * segments)))) if playing else 0
            for i in range(segments):
                y1 = y_bottom - i * (segment_h + gap)
                y0 = y1 - segment_h
                if i < lit_segments:
                    if i >= 7:
                        fill = (255, 215, 80, 255)
                    elif i >= 4:
                        fill = (110, 225, 100, 255)
                    else:
                        fill = (235, 245, 255, 255)
                else:
                    fill = (255, 255, 255, 38) if playing else (170, 170, 170, 82)
                draw.rounded_rectangle((x0, y0, x1, y1), radius=2, fill=fill)

        return image

    def _update_tray_icon_image(self) -> bool:
        if self._own_tray_icon is None:
            self._stop_tray_meter()
            return False
        try:
            self._tray_meter_frame += 1
            self._own_tray_icon.icon = self._make_tray_icon_image()
            self._own_tray_icon.title = 'M3U Radio - %s - %s' % (
                'Playing' if self._player.is_playing else 'Stopped',
                self._display_name(),
            )
        except Exception:
            log.debug('Could not update separate tray icon image', exc_info=True)
        return self._player.is_playing and self._own_tray_icon is not None

    def _sync_tray_meter(self) -> None:
        if self._own_tray_icon is None:
            self._stop_tray_meter()
            return
        if self._player.is_playing:
            if self._tray_meter_source is None:
                self._tray_meter_source = GLib.timeout_add(self._meter_update_interval_value(), self._tray_meter_tick)
            self._update_tray_icon_image()
        else:
            self._audio_level = 0.0
            self._audio_level_db = -60.0
            self._audio_levels = [0.0, 0.0, 0.0]
            self._audio_level_dbs = [-60.0, -60.0, -60.0]
            self._stop_tray_meter()
            self._update_tray_icon_image()

    def _tray_meter_tick(self) -> bool:
        keep_running = self._update_tray_icon_image()
        if not keep_running:
            self._tray_meter_source = None
        return keep_running

    def _stop_tray_meter(self) -> None:
        if self._tray_meter_source is not None:
            try:
                GLib.source_remove(self._tray_meter_source)
            except Exception:
                pass
            self._tray_meter_source = None

    def _install_own_tray_icon(self) -> bool:
        if self._own_tray_icon is not None:
            return True
        try:
            import pystray
        except Exception as error:
            self._last_install_details = 'Separate tray icon failed: %s' % error
            return False
        try:
            image = self._make_tray_icon_image()
        except Exception as error:
            self._last_install_details = 'Separate tray icon failed: %s' % error
            return False

        def toggle(_icon=None, _item=None):
            GLib.idle_add(self._toggle_playback)

        def show_controller(_icon=None, _item=None):
            GLib.idle_add(self._show_controller_window, _('Separate M3U tray icon is active.'))

        def show_settings(_icon=None, _item=None):
            GLib.idle_add(self._show_settings_window)

        def show_diag(_icon=None, _item=None):
            GLib.idle_add(self._show_diagnostics_window)

        def hide_icon(_icon=None, _item=None):
            GLib.idle_add(self._remove_own_tray_icon)

        def make_select(index: int):
            def select(_icon=None, _item=None):
                GLib.idle_add(self._select_playlist, index)
            return select

        def menu_items():
            items = [pystray.MenuItem(lambda _item: ('Stop ' if self._player.is_playing else 'Play ') + self._display_name(), toggle, default=True)]
            for i, entry in enumerate(self._playlist_entries()):
                items.append(pystray.MenuItem(lambda _item, i=i, entry=entry: ('● ' if i == self._current_playlist_index() else '○ ') + entry.name, make_select(i)))
            items.extend([
                pystray.MenuItem('Settings', show_settings),
                pystray.MenuItem('Show controller', show_controller),
                pystray.MenuItem('Diagnostics', show_diag),
                pystray.MenuItem('Hide M3U tray icon', hide_icon),
            ])
            return tuple(items)

        menu = pystray.Menu(menu_items)
        try:
            self._own_tray_icon = pystray.Icon('gajim-m3u-radio', image, 'M3U Radio', menu)
            run_detached = getattr(self._own_tray_icon, 'run_detached', None)
            if callable(run_detached):
                run_detached()
            else:
                self._own_tray_thread = Thread(target=self._own_tray_icon.run, daemon=True)
                self._own_tray_thread.start()
            detail = 'Created a separate M3U tray icon.'
            if detail not in self._last_install_details:
                self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + detail
            self._sync_tray_meter()
            return True
        except Exception as error:
            self._own_tray_icon = None
            self._last_install_details = 'Could not create separate tray icon: %s' % error
            return False

    def _refresh_own_tray_menu(self) -> None:
        if self._own_tray_icon is None:
            return
        try:
            self._own_tray_icon.title = 'M3U Radio - %s - %s' % ('Playing' if self._player.is_playing else 'Stopped', self._display_name())
            self._own_tray_icon.update_menu()
        except Exception:
            log.debug('Could not refresh separate tray menu', exc_info=True)

    def _remove_own_tray_icon(self) -> bool:
        self._stop_tray_meter()
        if self._own_tray_icon is not None:
            icon = self._own_tray_icon
            self._own_tray_icon = None
            try:
                icon.stop()
            except Exception:
                log.debug('Could not stop separate tray icon', exc_info=True)
        self._own_tray_thread = None
        return False

    def _show_controller_window(self, message: str = '') -> bool:
        if self._controller_window is not None:
            self._controller_window.present()
            return False
        window = Gtk.Window(title=self._controller_window_title())
        window.set_default_size(500, 230)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)
        now_playing_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        outer.append(now_playing_box)
        self._station_label = Gtk.Label(label=self._display_name())
        self._station_label.set_xalign(0)
        now_playing_box.append(self._station_label)
        self._now_playing_label = Gtk.Label(label='')
        self._now_playing_label.set_xalign(0)
        self._now_playing_label.set_wrap(False)
        now_playing_box.append(self._now_playing_label)
        self._status_label = Gtk.Label(label=message or _('Stopped'))
        self._status_label.set_xalign(0)
        self._status_label.set_wrap(True)
        outer.append(self._status_label)
        self._details_label = Gtk.Label(label=self._last_install_details)
        self._details_label.set_xalign(0)
        self._details_label.set_wrap(True)
        outer.append(self._details_label)
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        outer.append(buttons)
        self._toggle_button = Gtk.Button(label=_('Play'))
        self._toggle_button.connect('clicked', lambda *_args: self._toggle_playback())
        buttons.append(self._toggle_button)
        self._copy_song_button = Gtk.Button(label=_('Copy song'))
        self._copy_song_button.set_tooltip_text(_('Copy current song title'))
        self._copy_song_button.connect('clicked', self._copy_current_song_title)
        buttons.append(self._copy_song_button)
        settings = Gtk.Button(label=_('Settings'))
        settings.connect('clicked', lambda *_args: self._show_settings_window())
        buttons.append(settings)
        diag = Gtk.Button(label=_('Diagnostics'))
        diag.connect('clicked', lambda *_args: self._show_diagnostics_window())
        buttons.append(diag)
        window.connect('close-request', self._on_window_close_request)
        self._controller_window = window
        self._refresh_labels()
        window.present()
        return False

    def _on_window_close_request(self, *_args: Any) -> bool:
        if self._controller_window is not None:
            self._controller_window.hide()
        return True

    def _remove_controller_window(self) -> None:
        if self._controller_window is not None:
            try:
                self._controller_window.destroy()
            except Exception:
                pass
        self._controller_window = None
        self._status_label = None
        self._toggle_button = None
        self._details_label = None
        self._station_label = None
        self._now_playing_label = None
        self._copy_song_button = None

    def _show_settings_window(self) -> bool:
        if self._settings_window is not None:
            self._settings_window.present()
            return False
        window = Gtk.Window(title=_('M3U Radio Settings'))
        window.set_default_size(620, 420)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)
        help_label = Gtk.Label(label=_('Playlists: one per line, format: Name | M3U-or-stream-URL'))
        help_label.set_xalign(0)
        outer.append(help_label)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        outer.append(scrolled)
        view = Gtk.TextView()
        view.set_monospace(True)
        view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        view.get_buffer().set_text(str(self.config['playlists_text'] or DEFAULT_PLAYLISTS_TEXT))
        scrolled.set_child(view)
        self._settings_text_view = view
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        outer.append(buttons)
        save = Gtk.Button(label=_('Save playlists'))
        save.connect('clicked', lambda *_args: self._save_settings_window())
        buttons.append(save)
        close = Gtk.Button(label=_('Close'))
        close.connect('clicked', lambda *_args: window.hide())
        buttons.append(close)
        window.connect('close-request', self._on_settings_close_request)
        self._settings_window = window
        window.present()
        return False

    def _save_settings_window(self) -> None:
        if self._settings_text_view is None:
            return
        buffer = self._settings_text_view.get_buffer()
        start = buffer.get_start_iter()
        end = buffer.get_end_iter()
        text = buffer.get_text(start, end, True).strip()
        if not text:
            text = DEFAULT_PLAYLISTS_TEXT
        self.config['playlists_text'] = text
        entries = self._playlist_entries()
        if self._current_playlist_index() >= len(entries):
            self.config['current_playlist_index'] = 0
        self._set_status(_('Playlists saved'))
        self._refresh_everything()

    def _on_settings_close_request(self, *_args: Any) -> bool:
        if self._settings_window is not None:
            self._settings_window.hide()
        return True

    def _remove_settings_window(self) -> None:
        if self._settings_window is not None:
            try:
                self._settings_window.destroy()
            except Exception:
                pass
        self._settings_window = None
        self._settings_text_view = None

    def _show_diagnostics_window(self) -> bool:
        text = self._build_diagnostics()
        window = Gtk.Window(title=_('M3U Radio Diagnostics'))
        window.set_default_size(720, 420)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)
        copy = Gtk.Button(label=_('Copy diagnostics'))
        copy.connect('clicked', lambda *_args: self._copy_to_clipboard(window, text))
        outer.append(copy)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        outer.append(scrolled)
        view = Gtk.TextView()
        view.set_editable(False)
        view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        view.get_buffer().set_text(text)
        scrolled.set_child(view)
        window.present()
        return False

    def _copy_to_clipboard(self, window: Gtk.Window, text: str) -> None:
        try:
            window.get_clipboard().set(text)
        except Exception:
            pass

    def _copy_current_song_title(self, *_args: Any) -> None:
        text = self._metadata_text.strip()
        if not text:
            self._set_status(_('No song title to copy yet'))
            return
        self._copy_text_with_status(text, _('Copied song title: %s'), _('Could not copy song title'))

    def _copy_current_station_name(self, *_args: Any) -> None:
        text = self._display_name().strip()
        if not text:
            self._set_status(_('No station name to copy'))
            return
        self._copy_text_with_status(text, _('Copied station name: %s'), _('Could not copy station name'))

    def _copy_text_with_status(self, text: str, ok_template: str, error_text: str) -> None:
        window = self._controller_window or self._settings_window
        if window is None:
            root = getattr(app, 'window', None)
            window = root if hasattr(root, 'get_clipboard') else None
        if window is None:
            self._set_status(error_text)
            return
        try:
            window.get_clipboard().set(text)
            self._set_status(ok_template % self._marquee_text(text, 52))
        except Exception:
            log.debug('Could not copy text to clipboard', exc_info=True)
            self._set_status(error_text)

    def _controller_window_title(self) -> str:
        base = 'M3U Radio'
        if self._player.is_playing and self._metadata_text and self.config['show_now_playing']:
            return '%s  ♪  %s' % (base, self._marquee_text(self._metadata_text, 70))
        if self._player.is_playing:
            return '%s  ♪  %s' % (base, self._display_name())
        return base

    def _refresh_window_titles(self) -> None:
        self._refresh_controller_window_title()
        self._refresh_gajim_window_title()

    def _refresh_controller_window_title(self) -> None:
        if self._controller_window is None:
            return
        try:
            self._controller_window.set_title(self._controller_window_title())
        except Exception:
            log.debug('Could not update M3U controller window title', exc_info=True)

    def _refresh_gajim_window_title(self) -> None:
        window = getattr(app, 'window', None)
        if window is None or not hasattr(window, 'set_title'):
            return
        try:
            if self._main_window_title_original is None and hasattr(window, 'get_title'):
                self._main_window_title_original = window.get_title() or 'Gajim'
            base = self._main_window_title_original or 'Gajim'
            if self._player.is_playing and self._metadata_text and self.config['show_now_playing']:
                window.set_title('%s  ♪  %s' % (base, self._marquee_text(self._metadata_text, 70)))
            else:
                window.set_title(base)
        except Exception:
            log.debug('Could not update Gajim window title', exc_info=True)

    def _restore_window_titles(self) -> None:
        if self._controller_window is not None:
            try:
                self._controller_window.set_title('M3U Radio')
            except Exception:
                pass
        window = getattr(app, 'window', None)
        if window is not None and hasattr(window, 'set_title') and self._main_window_title_original:
            try:
                window.set_title(self._main_window_title_original)
            except Exception:
                pass
        self._main_window_title_original = None

    def _build_diagnostics(self) -> str:
        icon = self._find_pystray_icon()
        lines = [
            'M3U Radio Menu v0.24 diagnostics',
            'install_details=%s' % self._last_install_details,
            'playing=%s' % self._player.is_playing,
            'backend=%s' % self._player.backend_name,
            'gst_level_meter=%s' % self._player.has_audio_level,
            'gst_spectrum_meter=%s' % self._player.has_frequency_meter,
            'tray_meter_mode=three_band',
            'meter_sensitivity=%.2f' % self._meter_sensitivity_value(),
            'meter_update_interval_ms=%s' % self._meter_update_interval_value(),
            'audio_level=%.3f' % self._audio_level,
            'audio_level_db=%.1f dB' % self._audio_level_db,
            'audio_levels=bass=%.3f mid=%.3f treble=%.3f' % tuple(self._audio_levels),
            'audio_level_dbs=bass=%.1f mid=%.1f treble=%.1f dB' % tuple(self._audio_level_dbs),
            'current_playlist=%s' % self._display_name(),
            'metadata=%s' % self._metadata_text,
            'publish_now_playing_status=%s' % self.config['publish_now_playing_status'],
            'last_published_status=%s' % self._last_published_status,
            'playlist_count=%s' % len(self._playlist_entries()),
            'app.app=%r' % getattr(app, 'app', None),
            'app.app.systray=%r' % getattr(getattr(app, 'app', None), 'systray', None),
            'found_pystray_icon=%r' % icon,
            'own_tray_icon=%r' % self._own_tray_icon,
            'own_tray_thread=%r' % self._own_tray_thread,
            'tray_meter_source=%r' % self._tray_meter_source,
            'tray_meter_running=%s' % (self._tray_meter_source is not None),
            'roster_widget=%r parent=%r' % (self._roster_widget, self._roster_widget_parent),
        ]
        if icon is not None:
            lines.append('icon_type=%s.%s' % (icon.__class__.__module__, icon.__class__.__name__))
            lines.append('icon_menu=%r' % getattr(icon, 'menu', None))
            lines.append('icon_visible=%r' % getattr(icon, 'visible', None))
        return '\n'.join(lines)

    def _refresh_labels(self) -> None:
        if self._toggle_button is not None:
            self._toggle_button.set_label(_('Stop') if self._player.is_playing else _('Play'))
        if self._details_label is not None:
            self._details_label.set_label(self._last_install_details)
        if self._station_label is not None:
            self._station_label.set_label(self._display_name())
        if self._now_playing_label is not None:
            if self._metadata_text and self.config['show_now_playing']:
                self._now_playing_label.set_label(_('Now playing: %s') % self._marquee_text(self._metadata_text, 52))
            else:
                self._now_playing_label.set_label(_('Now playing: no metadata yet') if self._player.is_playing else '')

    def _set_status(self, text: str) -> None:
        if self._status_label is not None:
            self._status_label.set_label(text)

    def _refresh_marquee(self) -> None:
        if self._player.is_playing and self._metadata_text and self.config['show_now_playing']:
            if self._marquee_source is None:
                self._marquee_source = GLib.timeout_add(700, self._tick_marquee)
        else:
            self._stop_marquee()

    def _tick_marquee(self) -> bool:
        if not self._player.is_playing or not self._metadata_text:
            self._marquee_source = None
            self._refresh_window_titles()
            return False
        self._marquee_offset += 1
        self._refresh_labels()
        self._refresh_roster_button()
        self._refresh_window_titles()
        return True

    def _stop_marquee(self) -> None:
        if self._marquee_source is not None:
            try:
                GLib.source_remove(self._marquee_source)
            except Exception:
                pass
            self._marquee_source = None
        self._refresh_window_titles()

    def _start_status_scroll(self) -> None:
        if not self.config['publish_now_playing_status']:
            return
        if not self._player.is_playing:
            return
        if self._status_scroll_source is None:
            interval = self._status_scroll_interval_seconds()
            self._status_scroll_source = GLib.timeout_add_seconds(interval, self._tick_status_scroll)
        self._publish_now_playing_status_once()

    def _stop_status_scroll(self, restore: bool = False) -> None:
        if self._status_scroll_source is not None:
            try:
                GLib.source_remove(self._status_scroll_source)
            except Exception:
                pass
            self._status_scroll_source = None
        self._status_scroll_offset = 0
        self._last_published_status = ''
        if restore and self.config['restore_status_on_stop']:
            self._restore_previous_status()

    def _tick_status_scroll(self) -> bool:
        if not self.config['publish_now_playing_status'] or not self._player.is_playing:
            self._status_scroll_source = None
            return False
        self._status_scroll_offset += 1
        self._publish_now_playing_status_once()
        return True

    def _publish_now_playing_status_once(self) -> None:
        if not self.config['publish_now_playing_status'] or not self._player.is_playing:
            return
        text = self._network_status_text()
        if not text or text == self._last_published_status:
            return
        if self._publish_status_message(text):
            self._last_published_status = text

    def _network_status_text(self) -> str:
        if self._metadata_text:
            base = '♪ %s — %s' % (self._display_name(), self._metadata_text)
        else:
            base = '♪ %s' % self._display_name()
        width = self._status_scroll_width_chars()
        if len(base) <= width:
            return base
        padded = base + '   •   '
        offset = self._status_scroll_offset % len(padded)
        return (padded + padded)[offset:offset + width]

    def _capture_previous_status(self) -> None:
        if self._previous_status_message is not None:
            return
        self._previous_status_message = self._get_global_status_message()
        self._previous_status_show = self._get_global_status_show()

    def _restore_previous_status(self) -> None:
        if self._previous_status_message is None:
            return
        message = self._previous_status_message or ''
        self._publish_status_message(message, show=self._previous_status_show)
        self._previous_status_message = None
        self._previous_status_show = None
        self._main_window_title_original = None

    def _publish_status_message(self, message: str, show: str | None = None) -> bool:
        # This updates your public XMPP presence status message. Gajim's API moved
        # across versions, so keep this deliberately defensive.
        gio_app = getattr(app, 'app', None)
        show_value = show or self._get_global_status_show() or 'online'
        candidates = []
        if gio_app is not None:
            candidates.append(getattr(gio_app, 'change_status', None))
            candidates.append(getattr(gio_app, '_change_status', None))
        for fn in candidates:
            if not callable(fn):
                continue
            for args in ((show_value, message), (show_value, message, False), (message,),):
                try:
                    fn(*args)
                    return True
                except TypeError:
                    continue
                except Exception:
                    log.debug('Could not publish radio status through %r', fn, exc_info=True)
                    break
        # Last-resort per-account attempt for older/newer internal APIs.
        try:
            clients = getattr(app, 'connections', None) or getattr(app, 'clients', None)
            if isinstance(clients, dict):
                ok = False
                for client in clients.values():
                    fn = getattr(client, 'change_status', None)
                    if callable(fn):
                        try:
                            fn(show_value, message)
                            ok = True
                        except Exception:
                            log.debug('Could not publish radio status through client', exc_info=True)
                return ok
        except Exception:
            pass
        return False

    def _get_global_status_message(self) -> str:
        try:
            from gajim.common.util import status as status_util
            fn = getattr(status_util, 'get_global_status_message', None)
            if callable(fn):
                value = fn()
                if value is not None:
                    return str(value)
        except Exception:
            pass
        try:
            settings = getattr(app, 'settings', None)
            if settings is not None:
                for key in ('statusmsg', 'status_message', 'global_status_message'):
                    try:
                        value = settings.get_app_setting(key)
                        if value is not None:
                            return str(value)
                    except Exception:
                        pass
        except Exception:
            pass
        return ''

    def _get_global_status_show(self) -> str:
        for value in self._status_show_candidates():
            if value:
                return value
        return 'online'

    def _status_show_candidates(self) -> list[str]:
        values: list[str] = []
        try:
            from gajim.common.util import status as status_util
            for name in ('get_global_status', 'get_global_show', 'get_status'):
                fn = getattr(status_util, name, None)
                if callable(fn):
                    try:
                        values.append(str(fn()))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            settings = getattr(app, 'settings', None)
            if settings is not None:
                for key in ('status', 'global_status', 'show'):
                    try:
                        value = settings.get_app_setting(key)
                        if value is not None:
                            values.append(str(value))
                    except Exception:
                        pass
        except Exception:
            pass
        allowed = {'online', 'chat', 'away', 'xa', 'dnd', 'invisible', 'offline'}
        return [value for value in values if value in allowed]

    def _status_scroll_width_chars(self) -> int:
        try:
            value = int(self.config['status_scroll_width'])
        except Exception:
            value = 64
        return max(24, min(value, 120))

    def _status_scroll_interval_seconds(self) -> int:
        try:
            value = int(self.config['status_scroll_interval'])
        except Exception:
            value = 6
        return max(4, min(value, 60))

    def _marquee_text(self, text: str, width: int) -> str:
        if len(text) <= width:
            return text
        padded = text + '   •   '
        offset = self._marquee_offset % len(padded)
        doubled = padded + padded
        return doubled[offset:offset + width]

    def _playlist_entries(self) -> list[PlaylistEntry]:
        raw = str(self._cfg('playlists_text', '') or '').strip()
        entries: list[PlaylistEntry] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '|' in line:
                name, url = line.split('|', 1)
            elif ',' in line:
                name, url = line.split(',', 1)
            else:
                name, url = '', line
            name = name.strip()
            url = url.strip()
            if not url:
                continue
            if not name:
                name = url
            entries.append(PlaylistEntry(name=name, url=url))
        if not entries:
            name = str(self._cfg('display_name', DEFAULT_NAME)).strip() or DEFAULT_NAME
            url = str(self._cfg('playlist_url', DEFAULT_PLAYLIST_URL)).strip() or DEFAULT_PLAYLIST_URL
            entries.append(PlaylistEntry(name=name, url=url))
        return entries

    def _current_playlist_index(self) -> int:
        try:
            index = int(self._cfg('current_playlist_index', 0))
        except Exception:
            index = 0
        entries = self._playlist_entries()
        if not entries:
            return 0
        return max(0, min(index, len(entries) - 1))

    def _current_playlist(self) -> PlaylistEntry:
        entries = self._playlist_entries()
        return entries[self._current_playlist_index()]

    def _display_name(self) -> str:
        try:
            return self._current_playlist().name or DEFAULT_NAME
        except Exception:
            return str(self._cfg('display_name', DEFAULT_NAME)).strip() or DEFAULT_NAME


    def _cfg(self, key: str, default: Any = None) -> Any:
        try:
            return self.config[key]
        except Exception:
            return default

    @staticmethod
    def _get_gio_application() -> Any | None:
        for candidate in (getattr(app, 'app', None), getattr(app, 'window', None)):
            if candidate is None:
                continue
            if hasattr(candidate, 'add_action'):
                return candidate
            if hasattr(candidate, 'get_application'):
                try:
                    application = candidate.get_application()
                    if application is not None and hasattr(application, 'add_action'):
                        return application
                except Exception:
                    pass
        return None
