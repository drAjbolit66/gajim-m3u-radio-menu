# M3U Radio Menu v0.17

Changes in this build:

- removed the Copy station buttons from the controller window and the Gajim/sidebar radio row;
- kept the Copy song button for copying the current song title;
- the current song title now scrolls in the Gajim main window title while playback metadata is available;
- the controller window title also shows the scrolling current song title;
- the original Gajim window title is restored when playback stops or the plugin is disabled.
