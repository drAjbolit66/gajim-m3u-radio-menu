from .m3u_radio_menu import M3URadioMenuPlugin  # noqa: F401
