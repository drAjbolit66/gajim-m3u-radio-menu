# M3U Radio Menu v0.14

Fixed installer archive layout for Gajim 2.4.x and keeps the settings-dialog type fix.
