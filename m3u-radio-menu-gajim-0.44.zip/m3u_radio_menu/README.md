# Gadgim Gadget v0.44.0

Changes in this build:

- changed the inline Gajim volume slider from horizontal to vertical;
- replaced the default station with `4duk | http://4duk.ru/4duk/128m3u.m3u`.


- added **Show M3U tray icon** to the Gajim/tray menu and roster menu, so the separate M3U tray icon can be restored after **Hide M3U tray icon** without opening plugin settings;
- added **Copy current song** to tray/TID menus;
- kept the existing roster/sidebar copy-song button;
- added **Export stations** in the radio settings window; it saves the station list as a UTF-8 text configuration file with the `.gadgim-gadget` extension;
- kept the 0.25 behavior where the separate controller window does not appear on Gajim startup.


0.34: fixes the tray show/hide eye icon direction: open eye means the separate tray icon is visible, crossed eye means it is hidden.
0.33: hides the roster title label when the gadget row is installed and simplifies the tray meter to one left column.


## 0.34

- Fixed the Show/Hide tray button icon direction: open eye = tray icon visible; crossed/hidden eye = tray icon hidden.

## 0.33

Adds optional space-saving controls: hide the roster/list title, hide the search field, and hide the filter button from the Gadgim Gadget configuration dialog. These are enabled by default and can be switched off if Gajim layout changes.
