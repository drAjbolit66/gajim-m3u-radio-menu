from __future__ import annotations

from typing import Any, TYPE_CHECKING
from gi.repository import Gtk
from gajim.gtk.const import Setting, SettingKind, SettingType
from gajim.gtk.settings import SettingsDialog
from gajim.plugins.plugins_i18n import _

if TYPE_CHECKING:
    from .m3u_radio_menu import M3URadioMenuPlugin


_TEXT_KEYS = {
    'status_scroll_width',
    'status_scroll_interval',
}


def _entry_value(value: Any) -> str:
    """Gajim 2.4.x SettingsDialog asserts ENTRY values are str.

    Older plugin versions may have persisted int values for the status
    width/interval settings. Cast every ENTRY value here so the config
    dialog can open even with those old persisted values.
    """
    if value is None:
        return ''
    return str(value)


def _switch_value(value: Any) -> bool:
    return bool(value)


class M3URadioMenuConfigDialog(SettingsDialog):
    def __init__(self, plugin: M3URadioMenuPlugin, parent: Gtk.Window) -> None:
        self.plugin = plugin
        settings = [
            Setting(SettingKind.SWITCH, _('Try to add items to Gajim tray menu'), SettingType.VALUE, _switch_value(self.plugin.config['try_gajim_tray_menu']), callback=self._on_setting, data='try_gajim_tray_menu'),
            Setting(SettingKind.SWITCH, _('Try to add a visual row to the roster/sidebar area'), SettingType.VALUE, _switch_value(self.plugin.config['try_roster_button']), callback=self._on_setting, data='try_roster_button'),
            Setting(SettingKind.SWITCH, _('Create separate tray icon when Gajim menu is unavailable'), SettingType.VALUE, _switch_value(self.plugin.config['create_own_tray_icon']), callback=self._on_setting, data='create_own_tray_icon'),
            Setting(SettingKind.SWITCH, _('Hide roster/list title to free space'), SettingType.VALUE, _switch_value(self.plugin.config['hide_roster_title']), callback=self._on_setting, data='hide_roster_title'),
            Setting(SettingKind.SWITCH, _('Hide roster search field'), SettingType.VALUE, _switch_value(self.plugin.config['hide_roster_search']), callback=self._on_setting, data='hide_roster_search'),
            Setting(SettingKind.SWITCH, _('Hide roster filter button'), SettingType.VALUE, _switch_value(self.plugin.config['hide_roster_filter_button']), callback=self._on_setting, data='hide_roster_filter_button'),
            Setting(SettingKind.SWITCH, _('Show now-playing metadata when available'), SettingType.VALUE, _switch_value(self.plugin.config['show_now_playing']), callback=self._on_setting, data='show_now_playing'),
            Setting(SettingKind.SWITCH, _('Publish current track in XMPP status message'), SettingType.VALUE, _switch_value(self.plugin.config['publish_now_playing_status']), callback=self._on_setting, data='publish_now_playing_status'),
            Setting(SettingKind.SWITCH, _('Restore previous XMPP status message on stop'), SettingType.VALUE, _switch_value(self.plugin.config['restore_status_on_stop']), callback=self._on_setting, data='restore_status_on_stop'),
            Setting(SettingKind.ENTRY, _('Status scroll width, characters'), SettingType.VALUE, _entry_value(self.plugin.config['status_scroll_width']), callback=self._on_setting, data='status_scroll_width'),
            Setting(SettingKind.ENTRY, _('Status update interval, seconds'), SettingType.VALUE, _entry_value(self.plugin.config['status_scroll_interval']), callback=self._on_setting, data='status_scroll_interval'),
        ]
        SettingsDialog.__init__(self, parent, _('Gadgim Gadget Configuration'), Gtk.DialogFlags.MODAL, settings, '')

    def _on_setting(self, value: Any, data: Any) -> None:
        if data in _TEXT_KEYS:
            value = _entry_value(value)
        self.plugin.config[data] = value
        self.plugin.refresh_ui()
