from __future__ import annotations

import inspect
import math
import time
import logging
from pathlib import Path
import os
import shutil
import subprocess
import urllib.request
import types
from dataclasses import dataclass
from functools import partial
from threading import Thread
from typing import Any, Callable, Optional

from gi.repository import Gio, GLib, Gtk, Pango
try:
    from gi.repository import Gst
except Exception:
    Gst = None

from gajim.common import app
from gajim.plugins import GajimPlugin
from gajim.plugins.plugins_i18n import _

from .config_dialog import M3URadioMenuConfigDialog

log = logging.getLogger('gajim.p.m3u_radio_menu')
DEFAULT_NAME = '4duk'
DEFAULT_PLAYLIST_URL = 'http://4duk.ru/4duk/128m3u.m3u'
DEFAULT_PLAYLISTS_TEXT = f'{DEFAULT_NAME} | {DEFAULT_PLAYLIST_URL}'
ACTION_NAME = 'm3u-radio-toggle'
ACTION_DETAILED = f'app.{ACTION_NAME}'
USER_AGENT = 'Gadgim Gadget/0.44'


@dataclass
class PlaylistEntry:
    name: str
    url: str


class RadioPlayer:
    def __init__(
        self,
        on_metadata: Callable[[str], None] | None = None,
        on_level: Callable[[Any, Any], None] | None = None,
    ) -> None:
        self._gst_player = None
        self._gst_volume_element = None
        self._gst_bus = None
        self._gst_level_supported = False
        self._gst_spectrum_supported = False
        self._meter_focus = 'lowmid'
        self._meter_update_interval_ms = 80
        self._volume = 1.0
        self._process: Optional[subprocess.Popen[str]] = None
        self._on_metadata = on_metadata
        self._on_level = on_level
        if Gst is not None:
            try:
                Gst.init(None)
            except Exception:
                log.exception('Could not initialize GStreamer')

    @property
    def is_playing(self) -> bool:
        if self._gst_player is not None:
            return True
        return self._process is not None and self._process.poll() is None

    @property
    def backend_name(self) -> str:
        if self._gst_player is not None:
            return 'GStreamer'
        if self._process is not None and self._process.poll() is None:
            return 'external player'
        return 'none'

    @property
    def has_audio_level(self) -> bool:
        return self._gst_player is not None and (self._gst_spectrum_supported or self._gst_level_supported)

    @property
    def has_frequency_meter(self) -> bool:
        return self._gst_player is not None and self._gst_spectrum_supported

    @property
    def meter_focus(self) -> str:
        return self._meter_focus

    @property
    def meter_update_interval_ms(self) -> int:
        return self._meter_update_interval_ms

    def set_meter_options(self, focus: str, update_interval_ms: int) -> None:
        if focus not in ('bass', 'lowmid', 'full'):
            focus = 'lowmid'
        self._meter_focus = focus
        self._meter_update_interval_ms = max(30, min(1000, int(update_interval_ms)))

    @property
    def volume(self) -> float:
        return self._volume

    def set_volume(self, volume: float) -> float:
        self._volume = max(0.0, min(1.5, float(volume)))
        if self._gst_player is not None:
            try:
                self._gst_player.set_property('volume', self._volume)
            except Exception:
                log.debug('Could not set GStreamer playbin volume', exc_info=True)
            if self._gst_volume_element is not None:
                try:
                    self._gst_volume_element.set_property('volume', self._volume)
                except Exception:
                    log.debug('Could not set GStreamer volume element', exc_info=True)
        return self._volume

    def change_volume(self, delta: float) -> float:
        return self.set_volume(self._volume + float(delta))

    def play(self, playlist_url: str) -> str:
        self.stop()
        stream_url = self._resolve(playlist_url)
        if Gst is not None:
            try:
                player = Gst.ElementFactory.make('playbin', 'm3u-radio-playbin')
                if player is not None:
                    player.set_property('uri', stream_url)
                    try:
                        player.set_property('volume', self._volume)
                    except Exception:
                        log.debug('Could not set initial GStreamer playbin volume', exc_info=True)
                    self._gst_volume_element = None
                    try:
                        volume_element = Gst.ElementFactory.make('volume', 'gadgim-gstreamer-volume')
                        if volume_element is not None:
                            volume_element.set_property('volume', self._volume)
                            player.set_property('audio-filter', volume_element)
                            self._gst_volume_element = volume_element
                    except Exception:
                        self._gst_volume_element = None
                        log.debug('Could not attach GStreamer volume filter', exc_info=True)
                    self._gst_level_supported = False
                    self._gst_spectrum_supported = False
                    bus = player.get_bus()
                    if bus is not None:
                        bus.add_signal_watch()
                        bus.connect('message::tag', self._on_gst_tag)
                        bus.connect('message::error', self._on_gst_error)
                        bus.connect('message::eos', self._on_gst_eos)
                        bus.connect('message::element', self._on_gst_element)
                        self._gst_bus = bus
                    player.set_state(Gst.State.PLAYING)
                    self._gst_player = player
                    return stream_url
            except Exception:
                log.exception('GStreamer failed, trying external player')
                self._gst_player = None
                self._gst_volume_element = None
                self._gst_bus = None
                self._gst_level_supported = False
                self._gst_spectrum_supported = False
        command = self._find_external_player()
        if command is None:
            raise RuntimeError('No playback backend found. Install GStreamer, mpv, vlc, cvlc, or ffplay.')
        volume_percent = str(int(round(self._volume * 100)))
        if command == 'ffplay':
            args = [command, '-nodisp', '-autoexit', '-volume', volume_percent, stream_url]
        elif command == 'mpv':
            args = [command, '--volume=' + volume_percent, stream_url]
        elif command in ('vlc', 'cvlc'):
            args = [command, '--gain', str(max(0.0, min(8.0, self._volume))), stream_url]
        else:
            args = [command, stream_url]
        self._process = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True)
        return stream_url

    def stop(self) -> None:
        if self._gst_player is not None:
            try:
                self._gst_player.set_state(Gst.State.NULL)
            except Exception:
                log.exception('Could not stop GStreamer player')
            self._gst_player = None
            self._gst_volume_element = None
            self._gst_level_supported = False
            self._gst_spectrum_supported = False
            self._emit_level(0.0, -60.0)
        if self._gst_bus is not None:
            try:
                self._gst_bus.remove_signal_watch()
            except Exception:
                pass
            self._gst_bus = None
        if self._process is not None:
            try:
                if self._process.poll() is None:
                    self._process.terminate()
                    try:
                        self._process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        self._process.kill()
            finally:
                self._process = None
            self._emit_level(0.0, -60.0)

    def _build_audio_analysis_filter(self) -> Any | None:
        # Tray icon no longer analyzes audio.  The visual indicator is a small
        # synthetic playback animation, which avoids GStreamer spectrum/level
        # processing and keeps CPU usage lower.
        self._gst_level_supported = False
        self._gst_spectrum_supported = False
        return None

    def _on_gst_tag(self, _bus: Any, message: Any) -> None:
        if self._on_metadata is None or Gst is None:
            return
        try:
            tags = message.parse_tag()
            title = self._tag_string(tags, Gst.TAG_TITLE)
            artist = self._tag_string(tags, Gst.TAG_ARTIST) or self._tag_string(tags, Gst.TAG_ALBUM_ARTIST)
            organization = self._tag_string(tags, Gst.TAG_ORGANIZATION)
            parts = []
            if artist:
                parts.append(artist)
            if title:
                parts.append(title)
            if not parts and organization:
                parts.append(organization)
            if parts:
                text = ' — '.join(parts)
                GLib.idle_add(self._on_metadata, text)
        except Exception:
            log.debug('Could not parse GStreamer tag message', exc_info=True)

    def _on_gst_element(self, _bus: Any, message: Any) -> None:
        if self._on_level is None:
            return
        try:
            structure = message.get_structure()
            if structure is None:
                return

            name = structure.get_name()
            if name == 'spectrum' and self._gst_spectrum_supported:
                try:
                    magnitudes = structure.get_value('magnitude')
                except Exception:
                    magnitudes = None
                if not magnitudes:
                    return
                dbs = self._spectrum_three_band_dbs(magnitudes)
                if dbs is None:
                    return
                normalized = [self._normalize_db_for_meter(db) for db in dbs]
                GLib.idle_add(self._emit_level, normalized, dbs)
                return

            if name != 'level' or self._gst_spectrum_supported:
                return

            # Fallback: use full-band RMS if spectrum messages are unavailable.
            values = None
            try:
                values = structure.get_value('rms')
            except Exception:
                values = None
            if not values:
                try:
                    values = structure.get_value('peak')
                except Exception:
                    values = None
            if not values:
                return

            db_values = []
            for value in values:
                try:
                    db_values.append(float(value))
                except Exception:
                    pass
            if not db_values:
                return

            db = max(db_values)
            normalized = self._normalize_db_for_meter(db)
            GLib.idle_add(self._emit_level, [normalized, normalized, normalized], [db, db, db])
        except Exception:
            log.debug('Could not parse GStreamer analysis message', exc_info=True)

    @staticmethod
    def _normalize_db_for_meter(db: float) -> float:
        # For a tiny tray icon, favor visible movement over strict metering.
        # Use a slightly higher floor and a soft non-linear lift so the bar
        # follows rhythm more clearly even at moderate levels.
        floor_db = -48.0
        clipped = max(floor_db, min(0.0, float(db)))
        normalized = (clipped - floor_db) / abs(floor_db)
        return max(0.0, min(1.0, pow(normalized, 0.72)))

    def _emit_level(self, level: Any, db: Any = -60.0) -> bool:
        if self._on_level is not None:
            try:
                self._on_level(level, db)
            except Exception:
                log.debug('Could not emit audio level', exc_info=True)
        return False

    def _on_gst_error(self, _bus: Any, message: Any) -> None:
        try:
            error, debug = message.parse_error()
            log.warning('GStreamer radio error: %s %s', error, debug)
        except Exception:
            pass

    def _on_gst_eos(self, *_args: Any) -> None:
        log.debug('GStreamer radio stream reached EOS')

    @staticmethod
    def _tag_string(tags: Any, tag: str) -> str:
        try:
            ok, value = tags.get_string(tag)
            return str(value) if ok and value else ''
        except Exception:
            return ''

    def _resolve(self, url: str) -> str:
        lowered = url.lower().split('?', 1)[0]
        if not lowered.endswith(('.m3u', '.m3u8', '.pls')):
            return url
        request = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(request, timeout=10) as response:
            text = response.read(128 * 1024).decode('utf-8', errors='replace')
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if line.lower().startswith('file') and '=' in line:
                line = line.split('=', 1)[1].strip()
            if line.startswith(('http://', 'https://')):
                return line
        raise RuntimeError('The playlist did not contain an HTTP/HTTPS stream URL.')

    @staticmethod
    def _find_external_player() -> Optional[str]:
        for candidate in ('mpv', 'vlc', 'cvlc', 'ffplay'):
            if shutil.which(candidate):
                return candidate
        return None


class M3URadioMenuPlugin(GajimPlugin):
    def init(self) -> None:
        self.description = _('Adds sidebar/tray controls to toggle Gadgim radio streams.')
        self.config_dialog = partial(M3URadioMenuConfigDialog, self)
        self.config_default_values = {
            'display_name': (DEFAULT_NAME, ''),
            'playlist_url': (DEFAULT_PLAYLIST_URL, ''),
            'playlists_text': (DEFAULT_PLAYLISTS_TEXT, ''),
            'current_playlist_index': (0, ''),
            'show_controller_on_enable': (False, ''),
            'create_own_tray_icon': (True, ''),
            'try_gajim_tray_menu': (True, ''),
            'try_roster_button': (True, ''),
            'hide_roster_title': (True, ''),
            'hide_roster_search': (True, ''),
            'hide_roster_filter_button': (True, ''),
            'show_now_playing': (True, ''),
            'publish_now_playing_status': (False, ''),
            'restore_status_on_stop': (True, ''),
            'status_scroll_width': ('64', ''),
            'status_scroll_interval': ('6', ''),
            'meter_focus': ('lowmid', ''),
            'meter_sensitivity': ('1.0', ''),
            'meter_update_interval_ms': ('125', ''),
            'player_volume': ('1.0', ''),
        }
        self._player = RadioPlayer(self._on_metadata, self._on_audio_level)
        self._player.set_volume(self._volume_value())
        self._action = None
        self._controller_window = None
        self._status_label = None
        self._toggle_button = None
        self._details_label = None
        self._station_label = None
        self._now_playing_label = None
        self._copy_song_button = None
        self._own_tray_icon = None
        self._own_tray_thread = None
        self._tray_meter_source = None
        self._tray_meter_frame = 0
        self._tray_display_level = 0.0
        self._tray_was_audible = False
        self._audio_level = 0.0
        self._audio_level_db = -60.0
        self._audio_levels = [0.0, 0.0, 0.0]
        self._audio_level_dbs = [-60.0, -60.0, -60.0]
        self._native_pystray_patch = None
        self._last_install_details = ''
        self._roster_widget = None
        self._roster_widget_parent = None
        self._roster_play_button = None
        self._roster_station_label = None
        self._roster_track_label = None
        self._roster_label = None
        self._roster_icon = None
        self._roster_copy_song_button = None
        self._roster_volume_scale = None
        self._roster_menu_button = None
        self._roster_popover = None
        self._hidden_header_label = None
        self._hidden_header_label_text = None
        self._hidden_header_label_visible = None
        self._hidden_roster_space_widgets = []
        self._settings_window = None
        self._settings_text_view = None
        self._metadata_text = ''
        self._marquee_offset = 0
        self._marquee_source = None
        self._status_scroll_source = None
        self._status_scroll_offset = 0
        self._last_published_status = ''
        self._previous_status_message = None
        self._previous_status_show = None
        self._main_window_title_original = None
        self._volume_window = None
        self._volume_scale = None
        self._tray_single_click_source = None
        self._own_tray_notify_original = None
        self._own_tray_click_hooked = False

    def activate(self) -> None:
        GLib.idle_add(self._install)

    def deactivate(self) -> None:
        self._stop_status_scroll(restore=True)
        self._stop_marquee()
        self._restore_window_titles()
        self._player.stop()
        self._stop_tray_meter()
        self._remove_own_tray_icon()
        self._restore_native_pystray_menu()
        self._restore_roster_space_widgets()
        self._remove_roster_button()
        self._remove_controller_window()
        self._remove_settings_window()
        self._remove_action()

    def refresh_ui(self) -> None:
        self._apply_meter_settings()
        self._restore_roster_space_widgets()
        self._remove_roster_button()
        if self.config['try_roster_button']:
            self._install_roster_button()
        self._apply_roster_space_options()
        self._restore_native_pystray_menu()
        inserted = self._try_patch_gajim_pystray_menu() if self.config['try_gajim_tray_menu'] else False
        if not inserted and self.config['create_own_tray_icon']:
            self._install_own_tray_icon()
        self._refresh_labels()
        self._refresh_native_pystray_menu()
        self._refresh_own_tray_menu()
        self._refresh_roster_button()

    def _install(self) -> bool:
        self._apply_meter_settings()
        self._install_action()
        if self.config['try_roster_button']:
            self._install_roster_button()
        self._apply_roster_space_options()
        inserted = self._try_patch_gajim_pystray_menu() if self.config['try_gajim_tray_menu'] else False
        if not inserted and self.config['create_own_tray_icon']:
            self._install_own_tray_icon()
        return False

    def _meter_focus_value(self) -> str:
        value = str(self.config['meter_focus']).strip().lower()
        return value if value in ('bass', 'lowmid', 'full') else 'lowmid'

    def _meter_sensitivity_value(self) -> float:
        try:
            value = float(str(self.config['meter_sensitivity']).replace(',', '.'))
        except Exception:
            value = 1.6
        return max(0.2, min(5.0, value))

    def _meter_update_interval_value(self) -> int:
        try:
            value = int(float(str(self.config['meter_update_interval_ms']).replace(',', '.')))
        except Exception:
            value = 80
        return max(80, min(1000, value))

    @staticmethod
    def _tray_visual_interval_value() -> int:
        # Synthetic tray animation only.  Around 8 FPS is enough for a clear
        # playing indicator and keeps the tray workload low.
        return 125

    def _volume_value(self) -> float:
        try:
            return max(0.0, min(1.5, float(self.config['player_volume'])))
        except Exception:
            return 1.0

    def _volume_percent(self) -> int:
        return int(round(self._volume_value() * 100))

    def _set_player_volume(self, volume: float, announce: bool = True) -> bool:
        volume = max(0.0, min(1.5, float(volume)))
        self.config['player_volume'] = '%.2f' % volume
        self._player.set_volume(volume)
        self._refresh_roster_volume_scale()
        self._refresh_own_tray_menu()
        if announce and self._own_tray_icon is not None:
            try:
                self._own_tray_icon.title = 'Gadgim Gadget - Volume %d%% - %s' % (self._volume_percent(), self._display_name())
            except Exception:
                pass
        return False

    def _change_player_volume(self, steps: int = 1) -> bool:
        step = 0.10
        return self._set_player_volume(self._volume_value() + (step * int(steps)))

    def _make_inline_volume_scale(self) -> Gtk.Scale:
        scale = Gtk.Scale.new_with_range(Gtk.Orientation.VERTICAL, 0, 150, 1)
        scale.set_value(self._volume_percent())
        scale.set_draw_value(False)
        scale.set_inverted(True)
        scale.set_size_request(28, 52)
        scale.set_hexpand(False)
        scale.set_vexpand(False)
        scale.set_tooltip_text(_('Player volume: %d%%') % self._volume_percent())

        def on_value_changed(widget: Gtk.Scale) -> None:
            value = int(round(widget.get_value()))
            widget.set_tooltip_text(_('Player volume: %d%%') % value)
            self._set_player_volume(value / 100.0, announce=False)

        scale.connect('value-changed', on_value_changed)
        return scale

    def _refresh_roster_volume_scale(self) -> None:
        if self._roster_volume_scale is None:
            return
        try:
            percent = self._volume_percent()
            if int(round(self._roster_volume_scale.get_value())) != percent:
                self._roster_volume_scale.set_value(percent)
            self._roster_volume_scale.set_tooltip_text(_('Player volume: %d%%') % percent)
        except Exception:
            log.debug('Could not refresh roster volume scale', exc_info=True)

    def _make_volume_menu_items(self, pystray_module: Any) -> tuple[Any, ...]:
        def show_volume(_icon=None, _item=None):
            GLib.idle_add(self._show_volume_window)

        return (
            pystray_module.MenuItem(lambda _item: 'Volume: %d%%...' % self._volume_percent(), show_volume),
        )

    def _show_volume_window(self) -> bool:
        if self._volume_window is not None:
            try:
                self._volume_scale.set_value(self._volume_percent())
                self._volume_window.present()
                return False
            except Exception:
                self._volume_window = None
                self._volume_scale = None

        window = Gtk.Window(title=_('Gadgim Gadget Volume'))
        window.set_default_size(280, 80)
        window.set_resizable(False)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)

        label = Gtk.Label(label=_('Player volume'))
        label.set_xalign(0)
        outer.append(label)

        scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 150, 1)
        scale.set_value(self._volume_percent())
        scale.set_digits(0)
        scale.set_hexpand(True)
        try:
            scale.add_mark(0, Gtk.PositionType.BOTTOM, '0%')
            scale.add_mark(100, Gtk.PositionType.BOTTOM, '100%')
            scale.add_mark(150, Gtk.PositionType.BOTTOM, '150%')
        except Exception:
            pass

        def on_value_changed(widget: Gtk.Scale) -> None:
            self._set_player_volume(widget.get_value() / 100.0, announce=False)

        scale.connect('value-changed', on_value_changed)
        outer.append(scale)

        def on_close(*_args: Any) -> bool:
            window.hide()
            return True

        window.connect('close-request', on_close)
        self._volume_window = window
        self._volume_scale = scale
        window.present()
        return False

    def _apply_meter_settings(self) -> None:
        self._player.set_meter_options(self._meter_focus_value(), self._meter_update_interval_value())

    def _install_action(self) -> None:
        self._remove_action()
        gio_app = self._get_gio_application()
        if gio_app is None:
            self._last_install_details = 'No Gio.Application object found.'
            return
        action = Gio.SimpleAction.new(ACTION_NAME, None)
        action.connect('activate', lambda *_args: self._toggle_playback())
        gio_app.add_action(action)
        self._action = action
        try:
            gio_app.set_accels_for_action(ACTION_DETAILED, ['<Primary><Alt>r'])
        except Exception:
            log.debug('Could not set accelerator', exc_info=True)

    def _remove_action(self) -> None:
        gio_app = self._get_gio_application()
        if gio_app is not None:
            try:
                gio_app.remove_action(ACTION_NAME)
            except Exception:
                pass
        self._action = None

    def _queue_toggle_playback(self, *_args: Any) -> bool:
        GLib.idle_add(self._toggle_playback)
        return False

    def _queue_select_playlist(self, index: int, *_args: Any) -> bool:
        GLib.idle_add(self._select_playlist, index)
        return False

    def _toggle_playback(self) -> None:
        if self._player.is_playing:
            self._stop_status_scroll(restore=True)
            self._player.stop()
            self._metadata_text = ''
            self._set_status(_('Stopped'))
        else:
            try:
                self._apply_meter_settings()
                entry = self._current_playlist()
                stream = self._player.play(entry.url)
                self._metadata_text = ''
                self._capture_previous_status()
                self._start_status_scroll()
                self._set_status(_('Playing: %s') % stream)
            except Exception as error:
                log.exception('Could not start radio')
                self._set_status(_('Error: %s') % error)
        self._refresh_everything()

    def _select_playlist(self, index: int, start_playing: bool | None = None) -> None:
        entries = self._playlist_entries()
        if not entries:
            return
        index = max(0, min(index, len(entries) - 1))
        was_playing = self._player.is_playing
        self.config['current_playlist_index'] = index
        self._metadata_text = ''
        if was_playing or start_playing:
            self._stop_status_scroll(restore=False)
            self._player.stop()
            try:
                self._apply_meter_settings()
                entry = self._current_playlist()
                stream = self._player.play(entry.url)
                self._capture_previous_status()
                self._start_status_scroll()
                self._set_status(_('Playing: %s') % stream)
            except Exception as error:
                self._set_status(_('Error: %s') % error)
        else:
            self._set_status(_('Selected: %s') % entries[index].name)
        self._refresh_everything()

    def _refresh_everything(self) -> None:
        self._refresh_labels()
        self._refresh_native_pystray_menu()
        self._refresh_own_tray_menu()
        self._refresh_roster_button()
        self._refresh_window_titles()
        self._refresh_marquee()
        self._sync_tray_meter()
        if self.config['publish_now_playing_status'] and self._player.is_playing:
            self._start_status_scroll()
        elif not self.config['publish_now_playing_status']:
            self._stop_status_scroll(restore=True)

    def _on_metadata(self, text: str) -> bool:
        if text and text != self._metadata_text:
            self._metadata_text = text
            self._marquee_offset = 0
            self._refresh_everything()
            self._publish_now_playing_status_once()
        return False

    def _on_audio_level(self, level: Any, db: Any = -60.0) -> None:
        if isinstance(level, (list, tuple)):
            targets = [float(value) for value in level[:3]]
        else:
            targets = [float(level), float(level), float(level)]
        while len(targets) < 3:
            targets.append(0.0)

        if isinstance(db, (list, tuple)):
            dbs = [float(value) for value in db[:3]]
        else:
            dbs = [float(db), float(db), float(db)]
        while len(dbs) < 3:
            dbs.append(-60.0)

        sensitivity = self._meter_sensitivity_value()
        reactive_targets = []
        for old_value, value in zip(self._audio_levels, targets):
            raw = max(0.0, min(1.0, value * sensitivity))
            # Tiny tray meters look better when weak levels are lifted a little
            # and transients get an extra punch.  Prioritize visible rhythm over
            # strict signal accuracy.
            boosted = min(1.0, pow(raw, 0.58) * 1.18)
            if boosted > 0.02:
                boosted = min(1.0, 0.08 + boosted)
            pulse = max(0.0, boosted - old_value)
            target = min(1.0, boosted + (pulse * 0.85))
            if target >= old_value:
                new_value = (old_value * 0.08) + (target * 0.92)
            else:
                new_value = (old_value * 0.84) + (target * 0.16)
            reactive_targets.append(max(0.0, min(1.0, new_value)))

        self._audio_levels = reactive_targets
        self._audio_level_dbs = dbs
        self._audio_level = max(reactive_targets)
        self._audio_level_db = max(dbs)

    def _plugin_asset_path(self, filename: str) -> str:
        return str(Path(__file__).with_name(filename))

    def _make_tray_toggle_image(self):
        # Use the standard symbolic eye icons again: the custom tiny bitmap looked
        # like a level meter in Gajim's compact toolbar.
        icon_name = 'view-reveal-symbolic' if self._own_tray_icon is not None else 'view-conceal-symbolic'
        image = Gtk.Image.new_from_icon_name(icon_name)
        image.set_pixel_size(18)
        return image

    def _install_roster_button(self) -> bool:
        if self._roster_widget is not None:
            return True
        target = self._find_roster_insertion_target()
        if target is None:
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Roster/sidebar insertion target was not found.'
            return False
        parent, after_child = target
        try:
            root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            root.set_margin_top(4)
            root.set_margin_bottom(4)
            root.set_margin_start(4)
            root.set_margin_end(4)
            root.set_hexpand(True)

            play_button = Gtk.Button()
            play_button.add_css_class('flat')
            play_button.set_tooltip_text(_('Play/stop Gadgim Gadget'))
            play_button.set_hexpand(True)
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=7)
            row.set_margin_start(6)
            row.set_margin_end(6)
            icon = Gtk.Image.new_from_icon_name('media-playback-start-symbolic')
            icon.set_pixel_size(16)
            labels = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            labels.set_hexpand(True)
            station_label = Gtk.Label(label=self._display_name())
            station_label.set_xalign(0)
            station_label.set_hexpand(True)
            station_label.set_ellipsize(Pango.EllipsizeMode.END)
            track_label = Gtk.Label(label='')
            track_label.set_xalign(0)
            track_label.set_hexpand(True)
            track_label.set_ellipsize(Pango.EllipsizeMode.END)
            labels.append(station_label)
            labels.append(track_label)
            row.append(icon)
            row.append(labels)
            play_button.set_child(row)
            play_button.connect('clicked', lambda *_args: self._toggle_playback())
            root.append(play_button)

            volume_scale = self._make_inline_volume_scale()
            root.append(volume_scale)

            copy_song_button = Gtk.Button()
            copy_song_button.add_css_class('flat')
            copy_song_button.set_tooltip_text(_('Copy current song title'))
            copy_song_button.set_child(Gtk.Image.new_from_icon_name('edit-copy-symbolic'))
            copy_song_button.connect('clicked', self._copy_current_song_title)
            root.append(copy_song_button)

            menu_button = Gtk.Button()
            menu_button.add_css_class('flat')
            menu_button.set_tooltip_text(_('Show or hide the Gadgim tray icon'))
            menu_button.set_child(self._make_tray_toggle_image())
            menu_button.connect('clicked', lambda *_args: self._toggle_own_tray_icon())
            root.append(menu_button)

            settings_button = Gtk.Button()
            settings_button.add_css_class('flat')
            settings_button.set_tooltip_text(_('Gadget settings'))
            settings_button.set_child(Gtk.Image.new_from_icon_name('emblem-system-symbolic'))
            settings_button.connect('clicked', lambda *_args: self._show_settings_window())
            root.append(settings_button)

            if hasattr(parent, 'insert_child_after'):
                parent.insert_child_after(root, after_child)
            elif hasattr(parent, 'prepend'):
                parent.prepend(root)
            elif hasattr(parent, 'append'):
                parent.append(root)
            else:
                return False
            self._roster_widget = root
            self._roster_widget_parent = parent
            self._roster_play_button = play_button
            self._roster_station_label = station_label
            self._roster_track_label = track_label
            self._roster_label = station_label
            self._roster_icon = icon
            self._roster_copy_song_button = copy_song_button
            self._roster_volume_scale = volume_scale
            self._roster_menu_button = menu_button
            self._refresh_roster_tray_toggle_button()
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Added a visual M3U row to the roster/sidebar area.'
            self._refresh_roster_button()
            return True
        except Exception as error:
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Could not add roster/sidebar row: %s' % error
            log.debug('Could not add roster/sidebar row', exc_info=True)
            return False

    def _find_roster_insertion_target(self) -> tuple[Any, Any | None] | None:
        root = getattr(app, 'window', None)
        if root is None:
            return None
        widgets = list(self._walk_widgets(root))
        parent_of = {id(w): p for w, p in widgets}
        for widget, parent in widgets:
            if self._looks_like_search_widget(widget):
                # First try to place the gadget directly under the visible tab/list
                # title row (for example "Моя вкладка"), not in the search row.
                title_target = self._find_header_title_target_before_search(widget, widgets, parent_of)
                if title_target is not None:
                    return title_target

                # Fallback: use the container above the search row when possible.
                row = parent or widget
                search_row_container = self._nearest_appendable_ancestor(row, widgets)
                if search_row_container is not None:
                    header_parent = parent_of.get(id(search_row_container))
                    if self._is_appendable_container(header_parent):
                        return header_parent, self._previous_sibling(search_row_container)
                    return search_row_container, row
        for widget, _parent in widgets:
            cls = widget.__class__.__name__.lower()
            if isinstance(widget, Gtk.Box) and ('sidebar' in cls or 'list' in cls or 'box' in cls):
                return widget, None
        return None

    def _find_header_title_target_before_search(self, search_widget: Any, widgets: list[tuple[Any, Any | None]], parent_of: dict[int, Any | None]) -> tuple[Any, Any | None] | None:
        try:
            search_pos = next(i for i, (w, _p) in enumerate(widgets) if w is search_widget)
        except StopIteration:
            return None
        search_chain = self._ancestor_chain(search_widget, parent_of)
        search_chain_ids = {id(w): i for i, w in enumerate(search_chain)}

        # Walk backwards from Search; the nearest short, non-placeholder label is
        # usually the active list/tab title. In that layout its row and the search
        # row are siblings, which lets us insert the gadget between them.
        for label, _label_parent in reversed(widgets[:search_pos]):
            if not isinstance(label, Gtk.Label):
                continue
            text = self._safe_label_text(label).strip()
            if not text or self._looks_like_non_header_label(text):
                continue
            label_chain = self._ancestor_chain(label, parent_of)
            for idx, common in enumerate(label_chain[1:], start=1):
                common_index = search_chain_ids.get(id(common))
                if common_index is None or not self._is_appendable_container(common):
                    continue
                label_child = label_chain[idx - 1]
                search_child = search_chain[common_index - 1] if common_index > 0 else search_widget
                if label_child is search_child:
                    continue
                if self.config['hide_roster_title']:
                    self._hide_header_title_label(label)
                return common, label_child
        return None

    def _hide_header_title_label(self, label: Any) -> None:
        try:
            if self._hidden_header_label is label:
                return
            if self._hidden_header_label is not None:
                self._restore_hidden_header_label()
            self._hidden_header_label = label
            self._hidden_header_label_text = self._safe_label_text(label)
            self._hidden_header_label_visible = label.get_visible() if hasattr(label, 'get_visible') else True
            if hasattr(label, 'set_visible'):
                label.set_visible(False)
            elif hasattr(label, 'set_text'):
                label.set_text('')
            elif hasattr(label, 'set_label'):
                label.set_label('')
            self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + 'Hidden the roster/list title label to free space.'
        except Exception:
            log.debug('Could not hide roster/list title label', exc_info=True)

    def _restore_hidden_header_label(self) -> None:
        label = self._hidden_header_label
        if label is None:
            return
        self._hidden_header_label = None
        text = self._hidden_header_label_text
        visible = self._hidden_header_label_visible
        self._hidden_header_label_text = None
        self._hidden_header_label_visible = None
        try:
            if text is not None:
                if hasattr(label, 'set_text'):
                    label.set_text(text)
                elif hasattr(label, 'set_label'):
                    label.set_label(text)
            if visible is not None and hasattr(label, 'set_visible'):
                label.set_visible(bool(visible))
        except Exception:
            log.debug('Could not restore roster/list title label', exc_info=True)


    def _restore_roster_space_widgets(self) -> None:
        hidden = getattr(self, '_hidden_roster_space_widgets', [])
        self._hidden_roster_space_widgets = []
        for widget, visible, hexpand in reversed(hidden):
            try:
                if hasattr(widget, 'set_visible'):
                    widget.set_visible(bool(visible))
                if hexpand is not None and hasattr(widget, 'set_hexpand'):
                    widget.set_hexpand(bool(hexpand))
            except Exception:
                log.debug('Could not restore hidden roster widget', exc_info=True)

    def _remember_and_hide_roster_widget(self, widget: Any | None) -> None:
        if widget is None or not isinstance(widget, Gtk.Widget):
            return
        if widget is self._roster_widget or self._is_descendant(self._roster_widget, widget):
            return
        for existing, _visible, _hexpand in getattr(self, '_hidden_roster_space_widgets', []):
            if existing is widget:
                return
        try:
            visible = widget.get_visible() if hasattr(widget, 'get_visible') else True
            hexpand = widget.get_hexpand() if hasattr(widget, 'get_hexpand') else None
            self._hidden_roster_space_widgets.append((widget, visible, hexpand))
            if hasattr(widget, 'set_hexpand'):
                widget.set_hexpand(False)
            widget.set_visible(False)
        except Exception:
            log.debug('Could not hide roster widget', exc_info=True)

    def _apply_roster_space_options(self) -> None:
        self._restore_roster_space_widgets()
        if not (self.config['hide_roster_title'] or self.config['hide_roster_search'] or self.config['hide_roster_filter_button']):
            return
        root = getattr(app, 'window', None)
        if root is None:
            return
        try:
            widgets = list(self._walk_widgets(root))
            parent_of = {id(w): p for w, p in widgets}

            if self.config['hide_roster_title']:
                for widget, _parent in widgets:
                    if not isinstance(widget, Gtk.Label):
                        continue
                    text = self._safe_label_text(widget).strip()
                    if not text or self._looks_like_non_header_label(text):
                        continue
                    # The visible roster/list title is usually a short label right
                    # above the search field.  Hide only the first plausible one.
                    self._remember_and_hide_roster_widget(widget)
                    break

            if self.config['hide_roster_search']:
                for widget, _parent in widgets:
                    if self._looks_like_search_widget(widget):
                        self._remember_and_hide_roster_widget(self._compact_hide_target(widget, parent_of))
                        break

            if self.config['hide_roster_filter_button']:
                search_seen = False
                for widget, _parent in widgets:
                    if self._looks_like_search_widget(widget):
                        search_seen = True
                        continue
                    if search_seen and self._looks_like_filter_button(widget):
                        self._remember_and_hide_roster_widget(widget)
                        break
        except Exception:
            log.debug('Could not apply roster space options', exc_info=True)

    def _compact_hide_target(self, widget: Any, parent_of: dict[int, Any | None]) -> Any:
        target = widget
        current = widget
        for _ in range(3):
            parent = parent_of.get(id(current))
            if parent is None or parent is self._roster_widget or self._is_descendant(self._roster_widget, parent):
                break
            cls = parent.__class__.__name__.lower()
            if 'search' in cls or self._single_child_container(parent):
                target = parent
                current = parent
                continue
            break
        return target

    def _single_child_container(self, widget: Any) -> bool:
        try:
            first = widget.get_first_child()
            return first is not None and first.get_next_sibling() is None
        except Exception:
            return False

    def _is_descendant(self, widget: Any | None, ancestor: Any | None) -> bool:
        if widget is None or ancestor is None:
            return False
        try:
            current = widget
            for _ in range(30):
                if current is ancestor:
                    return True
                parent = current.get_parent() if hasattr(current, 'get_parent') else None
                if parent is None:
                    return False
                current = parent
        except Exception:
            return False
        return False

    def _looks_like_filter_button(self, widget: Any) -> bool:
        if not isinstance(widget, Gtk.Button):
            return False
        if widget in (self._roster_play_button, self._roster_copy_song_button, self._roster_menu_button):
            return False
        low = ' '.join(self._widget_text_bits(widget)).lower()
        if any(token in low for token in ('filter', 'фильтр', 'view-filter', 'funnel')):
            return True
        cls = widget.__class__.__name__.lower()
        if 'filter' in cls:
            return True
        return False

    def _widget_text_bits(self, widget: Any) -> list[str]:
        bits: list[str] = []
        for attr in ('get_tooltip_text', 'get_label', 'get_icon_name'):
            try:
                fn = getattr(widget, attr, None)
                if callable(fn):
                    value = fn()
                    if value:
                        bits.append(str(value))
            except Exception:
                pass
        try:
            child = widget.get_first_child()
            while child is not None:
                bits.extend(self._widget_text_bits(child))
                child = child.get_next_sibling()
        except Exception:
            pass
        return bits

    def _safe_label_text(self, label: Any) -> str:
        for method_name in ('get_label', 'get_text'):
            try:
                method = getattr(label, method_name, None)
                if callable(method):
                    value = method()
                    if value:
                        return str(value)
            except Exception:
                pass
        return ''

    def _looks_like_non_header_label(self, text: str) -> bool:
        low = text.lower()
        if len(text) > 80:
            return True
        if any(token in low for token in ('search', 'gajim', 'gadgim', 'm3u', '♪')):
            return True
        if text in {'+', '…', '...', '⚙'}:
            return True
        return False

    def _ancestor_chain(self, widget: Any, parent_of: dict[int, Any | None]) -> list[Any]:
        chain = [widget]
        current = widget
        seen = {id(widget)}
        for _ in range(20):
            parent = parent_of.get(id(current))
            if parent is None or id(parent) in seen:
                break
            chain.append(parent)
            seen.add(id(parent))
            current = parent
        return chain

    def _is_appendable_container(self, widget: Any | None) -> bool:
        return widget is not None and (
            hasattr(widget, 'insert_child_after') or hasattr(widget, 'append') or hasattr(widget, 'prepend')
        )

    def _previous_sibling(self, widget: Any) -> Any | None:
        try:
            return widget.get_prev_sibling()
        except Exception:
            return None

    def _walk_widgets(self, root: Any) -> list[tuple[Any, Any | None]]:
        result: list[tuple[Any, Any | None]] = []
        seen: set[int] = set()

        def add(obj: Any, parent: Any | None, depth: int) -> None:
            if obj is None or id(obj) in seen or depth > 30:
                return
            seen.add(id(obj))
            if isinstance(obj, Gtk.Widget):
                result.append((obj, parent))
                try:
                    child = obj.get_first_child()
                    while child is not None:
                        add(child, obj, depth + 1)
                        child = child.get_next_sibling()
                except Exception:
                    pass
                for meth in ('get_child', 'get_content', 'get_top_bar', 'get_bottom_bar', 'get_start_child', 'get_end_child', 'get_center_widget'):
                    try:
                        fn = getattr(obj, meth, None)
                        if callable(fn):
                            add(fn(), obj, depth + 1)
                    except Exception:
                        pass

        add(root, None, 0)
        return result

    def _looks_like_search_widget(self, widget: Any) -> bool:
        cls = widget.__class__.__name__.lower()
        if 'search' in cls and isinstance(widget, Gtk.Widget):
            return True
        for attr in ('get_placeholder_text', 'get_text'):
            try:
                fn = getattr(widget, attr, None)
                if callable(fn):
                    text = fn()
                    if text and 'search' in str(text).lower():
                        return True
            except Exception:
                pass
        return False

    def _nearest_appendable_ancestor(self, widget: Any, widgets: list[tuple[Any, Any | None]]) -> Any | None:
        parent_of = {id(w): p for w, p in widgets}
        obj = widget
        for _ in range(8):
            parent = parent_of.get(id(obj))
            if parent is None:
                return None
            if hasattr(parent, 'insert_child_after') or hasattr(parent, 'append') or hasattr(parent, 'prepend'):
                return parent
            obj = parent
        return None

    def _remove_roster_button(self) -> None:
        widget = self._roster_widget
        parent = self._roster_widget_parent
        self._roster_widget = None
        self._roster_widget_parent = None
        self._roster_play_button = None
        self._roster_station_label = None
        self._roster_track_label = None
        self._roster_label = None
        self._roster_icon = None
        self._roster_copy_song_button = None
        self._roster_volume_scale = None
        self._roster_menu_button = None
        self._roster_popover = None
        self._restore_hidden_header_label()
        if widget is None:
            return
        try:
            if parent is not None and hasattr(parent, 'remove'):
                parent.remove(widget)
            else:
                widget.unparent()
        except Exception:
            log.debug('Could not remove roster/sidebar row', exc_info=True)

    def _refresh_roster_button(self) -> None:
        if self._roster_widget is None:
            return
        try:
            if self._roster_icon is not None:
                self._roster_icon.set_from_icon_name('media-playback-stop-symbolic' if self._player.is_playing else 'media-playback-start-symbolic')
            if self._roster_station_label is not None:
                self._roster_station_label.set_label(self._roster_station_text())
            if self._roster_track_label is not None:
                self._roster_track_label.set_label(self._roster_track_text())
            self._refresh_roster_tray_toggle_button()
            self._refresh_roster_volume_scale()
        except Exception:
            pass

    def _roster_button_label(self) -> str:
        return self._roster_station_text()

    def _roster_station_text(self) -> str:
        prefix = '■ ' if self._player.is_playing else '▶ '
        return prefix + self._display_name()

    def _roster_track_text(self) -> str:
        if self.config['show_now_playing'] and self._player.is_playing and self._metadata_text:
            return self._marquee_text(self._metadata_text, 38)
        return ''

    def _refresh_roster_tray_toggle_button(self) -> None:
        if self._roster_menu_button is None:
            return
        try:
            label = _('Hide tray icon') if self._own_tray_icon is not None else _('Show tray icon')
            self._roster_menu_button.set_tooltip_text(label)
            self._roster_menu_button.set_child(self._make_tray_toggle_image())
        except Exception:
            log.debug('Could not refresh roster tray toggle button', exc_info=True)

    def _rebuild_roster_playlist_menu(self) -> None:
        if self._roster_popover is None:
            return
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        box.set_margin_top(6)
        box.set_margin_bottom(6)
        box.set_margin_start(6)
        box.set_margin_end(6)
        entries = self._playlist_entries()
        current = self._current_playlist_index()
        for i, entry in enumerate(entries):
            label = ('● ' if i == current else '○ ') + entry.name
            btn = Gtk.Button(label=label)
            btn.add_css_class('flat')
            btn.connect('clicked', self._on_playlist_button_clicked, i)
            box.append(btn)
        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        box.append(sep)
        toggle_play = Gtk.Button(label=_('Stop current station') if self._player.is_playing else _('Play current station'))
        toggle_play.add_css_class('flat')
        toggle_play.connect('clicked', lambda *_args: (self._roster_popover.popdown() if self._roster_popover is not None else None, self._toggle_playback()))
        box.append(toggle_play)
        copy_song = Gtk.Button(label=_('Copy current song'))
        copy_song.add_css_class('flat')
        copy_song.connect('clicked', lambda *_args: self._copy_current_song_title())
        box.append(copy_song)
        show_tray = Gtk.Button(label=_('Hide M3U tray icon') if self._own_tray_icon is not None else _('Show M3U tray icon'))
        show_tray.add_css_class('flat')
        show_tray.connect('clicked', lambda *_args: self._toggle_own_tray_icon())
        box.append(show_tray)
        settings = Gtk.Button(label=_('Gadget settings...'))
        settings.add_css_class('flat')
        settings.connect('clicked', lambda *_args: self._show_settings_window())
        box.append(settings)
        self._roster_popover.set_child(box)

    def _on_playlist_button_clicked(self, _button: Gtk.Button, index: int) -> None:
        if self._roster_popover is not None:
            self._roster_popover.popdown()
        self._select_playlist(index)

    def _try_patch_gajim_pystray_menu(self) -> bool:
        if self._native_pystray_patch is not None:
            return True
        try:
            import pystray
        except Exception as error:
            self._last_install_details = 'pystray is not importable: %s' % error
            return False
        icon = self._find_pystray_icon()
        if icon is None:
            self._last_install_details = 'Gajim systray exists, but no underlying pystray.Icon was found.'
            return False
        try:
            old_menu = getattr(icon, 'menu', None)
            if old_menu is None:
                self._last_install_details = 'Found Gajim pystray.Icon, but it has no menu.'
                return False

            def toggle(_icon=None, _item=None):
                GLib.idle_add(self._toggle_playback)

            def show_settings(_icon=None, _item=None):
                GLib.idle_add(self._show_settings_window)

            def toggle_own_icon(_icon=None, _item=None):
                GLib.idle_add(self._toggle_own_tray_icon)

            def copy_song(_icon=None, _item=None):
                GLib.idle_add(self._copy_current_song_title)

            def make_select(index: int):
                def select(_icon=None, _item=None):
                    GLib.idle_add(self._select_playlist, index)
                return select

            def items():
                result = [
                    pystray.MenuItem(lambda _item: ('Stop ' if self._player.is_playing else 'Play ') + self._display_name(), toggle, default=True, visible=False),
                ]
                for i, entry in enumerate(self._playlist_entries()):
                    result.append(pystray.MenuItem(lambda _item, i=i, entry=entry: ('● ' if i == self._current_playlist_index() else '○ ') + entry.name, make_select(i)))
                sep = getattr(pystray.Menu, 'SEPARATOR', None)
                if sep is not None:
                    result.append(sep)
                result.extend([
                    pystray.MenuItem('Copy current song', copy_song),
                    pystray.MenuItem(lambda _item: 'Hide M3U tray icon' if self._own_tray_icon is not None else 'Show M3U tray icon', toggle_own_icon),
                    pystray.MenuItem('Gadget settings', show_settings),
                ])
                if sep is not None:
                    result.append(sep)
                result.extend(self._read_pystray_menu_items(old_menu))
                return tuple(result)

            icon.menu = pystray.Menu(items)
            self._native_pystray_patch = (icon, old_menu)
            self._refresh_native_pystray_menu()
            self._last_install_details = 'Added Gadgim Gadget items to the existing Gajim tray menu.'
            return True
        except Exception as error:
            self._last_install_details = 'Could not wrap Gajim tray menu: %s' % error
            log.debug('Could not wrap Gajim tray menu', exc_info=True)
            return False

    def _read_pystray_menu_items(self, menu: Any) -> tuple[Any, ...]:
        try:
            return tuple(menu)
        except Exception:
            pass
        for attr in ('items', '_items'):
            try:
                value = getattr(menu, attr)
                if callable(value):
                    value = value()
                return tuple(value)
            except Exception:
                pass
        return ()

    def _find_pystray_icon(self) -> Any | None:
        roots = [getattr(app, 'app', None), getattr(getattr(app, 'app', None), 'systray', None), getattr(app, 'window', None), getattr(app, 'systray', None)]
        seen: set[int] = set()
        queue: list[tuple[Any, int]] = [(root, 0) for root in roots if root is not None]
        while queue:
            obj, depth = queue.pop(0)
            if id(obj) in seen:
                continue
            seen.add(id(obj))
            if self._looks_like_pystray_icon(obj):
                return obj
            if depth >= 8:
                continue
            try:
                names = dir(obj)
            except Exception:
                continue
            for name in names:
                if name.startswith('__'):
                    continue
                low = name.lower()
                if not any(token in low for token in ('tray', 'icon', 'backend', 'menu', 'pystray', 'status')):
                    continue
                try:
                    value = getattr(obj, name)
                except Exception:
                    continue
                if value is None or inspect.ismodule(value) or inspect.isclass(value) or callable(value):
                    continue
                queue.append((value, depth + 1))
        return None

    def _looks_like_pystray_icon(self, obj: Any) -> bool:
        module = getattr(obj.__class__, '__module__', '')
        name = getattr(obj.__class__, '__name__', '')
        return (module.startswith('pystray') and name == 'Icon') or (
            'pystray' in module.lower() and hasattr(obj, 'menu') and hasattr(obj, 'update_menu')
        )

    def _refresh_native_pystray_menu(self) -> None:
        if self._native_pystray_patch is None:
            return
        icon, _old_menu = self._native_pystray_patch
        try:
            icon.update_menu()
        except Exception:
            log.debug('Could not refresh Gajim pystray menu', exc_info=True)

    def _restore_native_pystray_menu(self) -> None:
        if self._native_pystray_patch is None:
            return
        icon, old_menu = self._native_pystray_patch
        self._native_pystray_patch = None
        try:
            icon.menu = old_menu
            icon.update_menu()
        except Exception:
            log.debug('Could not restore Gajim pystray menu', exc_info=True)

    @staticmethod
    def _synthetic_tray_pulse_level() -> float:
        # One-second pattern: strong pulse, weak pulse, weak pulse, short rest.
        # It is intentionally synthetic: it only says "radio is playing" and
        # does not try to measure the stream audio.
        phase = time.monotonic() % 1.0
        base_level = 0.18
        pulses = (
            (0.00, 1.00, 0.115),
            (0.34, 0.56, 0.100),
            (0.67, 0.44, 0.095),
        )
        level = base_level
        for center, amplitude, width in pulses:
            distance = min(abs(phase - center), 1.0 - abs(phase - center))
            if distance <= width:
                # Fast attack near the pulse center with a rounded release.
                shape = 1.0 - (distance / width)
                shape = shape * shape
                level = max(level, amplitude * shape)
        return max(0.0, min(1.0, level))

    def _make_tray_icon_image(self) -> Any:
        from PIL import Image, ImageDraw

        image = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        playing = self._player.is_playing

        segments = 9
        # A single wide column is much easier to see in a real tray than three
        # tiny columns.  It is a synthetic playback animation, not a VU meter.
        columns = [(5, 43)]
        y_bottom = 58
        segment_h = 4
        gap = 2

        if playing:
            target_level = self._synthetic_tray_pulse_level()
            if target_level >= self._tray_display_level:
                # Quick visible rise on each pulse.
                self._tray_display_level = (self._tray_display_level * 0.25) + (target_level * 0.75)
            else:
                # Smooth fall so the strong/weak/weak rhythm is readable.
                self._tray_display_level = (self._tray_display_level * 0.70) + (target_level * 0.30)
            display_level = max(0.0, min(1.0, self._tray_display_level))
        else:
            self._tray_display_level = 0.0
            self._tray_was_audible = False
            display_level = 0.0

        for _column_index, (x0, x1) in enumerate(columns):
            lit_segments = max(1, min(segments, int(round(display_level * segments)))) if playing and display_level > 0.0 else 0
            for i in range(segments):
                y1 = y_bottom - i * (segment_h + gap)
                y0 = y1 - segment_h
                if i < lit_segments:
                    if i >= 7:
                        fill = (255, 215, 80, 255)
                    elif i >= 4:
                        fill = (110, 225, 100, 255)
                    else:
                        fill = (235, 245, 255, 255)
                else:
                    fill = (255, 255, 255, 38) if playing else (170, 170, 170, 82)
                draw.rounded_rectangle((x0, y0, x1, y1), radius=2, fill=fill)

        return image

    def _update_tray_icon_image(self) -> bool:
        if self._own_tray_icon is None:
            self._stop_tray_meter()
            return False
        try:
            self._tray_meter_frame += 1
            self._own_tray_icon.icon = self._make_tray_icon_image()
            self._own_tray_icon.title = 'Gadgim Gadget - %s - %s - Volume %d%%' % (
                'Playing' if self._player.is_playing else 'Stopped',
                self._display_name(),
                self._volume_percent(),
            )
        except Exception:
            log.debug('Could not update separate tray icon image', exc_info=True)
        return self._player.is_playing and self._own_tray_icon is not None

    def _sync_tray_meter(self) -> None:
        if self._own_tray_icon is None:
            self._stop_tray_meter()
            return
        if self._player.is_playing:
            if self._tray_meter_source is None:
                self._tray_meter_source = GLib.timeout_add(self._tray_visual_interval_value(), self._tray_meter_tick)
            self._update_tray_icon_image()
        else:
            self._audio_level = 0.0
            self._audio_level_db = -60.0
            self._audio_levels = [0.0, 0.0, 0.0]
            self._audio_level_dbs = [-60.0, -60.0, -60.0]
            self._tray_display_level = 0.0
            self._tray_was_audible = False
            self._stop_tray_meter()
            self._update_tray_icon_image()

    def _tray_meter_tick(self) -> bool:
        keep_running = self._update_tray_icon_image()
        if not keep_running:
            self._tray_meter_source = None
        return keep_running

    def _stop_tray_meter(self) -> None:
        if self._tray_meter_source is not None:
            try:
                GLib.source_remove(self._tray_meter_source)
            except Exception:
                pass
            self._tray_meter_source = None

    def _install_own_tray_icon(self) -> bool:
        if self._own_tray_icon is not None:
            return True
        try:
            import pystray
        except Exception as error:
            self._last_install_details = 'Separate tray icon failed: %s' % error
            return False
        try:
            image = self._make_tray_icon_image()
        except Exception as error:
            self._last_install_details = 'Separate tray icon failed: %s' % error
            return False

        def toggle(_icon=None, _item=None):
            GLib.idle_add(self._toggle_playback)

        def show_settings(_icon=None, _item=None):
            GLib.idle_add(self._show_settings_window)

        def copy_song(_icon=None, _item=None):
            GLib.idle_add(self._copy_current_song_title)

        def hide_icon(_icon=None, _item=None):
            GLib.idle_add(self._remove_own_tray_icon)

        def make_select(index: int):
            def select(_icon=None, _item=None):
                GLib.idle_add(self._select_playlist, index)
            return select

        def menu_items():
            items = [
                pystray.MenuItem(lambda _item: ('Stop ' if self._player.is_playing else 'Play ') + self._display_name(), toggle, default=True, visible=False),
            ]
            for i, entry in enumerate(self._playlist_entries()):
                items.append(pystray.MenuItem(lambda _item, i=i, entry=entry: ('● ' if i == self._current_playlist_index() else '○ ') + entry.name, make_select(i)))
            sep = getattr(pystray.Menu, 'SEPARATOR', None)
            if sep is not None:
                items.append(sep)
            items.extend([
                pystray.MenuItem('Copy current song', copy_song),
                pystray.MenuItem('Settings', show_settings),
                pystray.MenuItem('Hide M3U tray icon', hide_icon),
            ])
            return tuple(items)

        menu = pystray.Menu(menu_items)
        try:
            self._own_tray_icon = pystray.Icon('gajim-m3u-radio', image, 'Gadgim Gadget', menu)
            run_detached = getattr(self._own_tray_icon, 'run_detached', None)
            if callable(run_detached):
                run_detached()
            else:
                self._own_tray_thread = Thread(target=self._own_tray_icon.run, daemon=True)
                self._own_tray_thread.start()
            detail = 'Created a separate Gadgim Gadget tray icon.'
            if detail not in self._last_install_details:
                self._last_install_details = (self._last_install_details + ' | ' if self._last_install_details else '') + detail
            self._sync_tray_meter()
            return True
        except Exception as error:
            self._own_tray_icon = None
            self._last_install_details = 'Could not create separate tray icon: %s' % error
            return False

    def _cancel_tray_single_click(self) -> None:
        if self._tray_single_click_source is not None:
            try:
                GLib.source_remove(self._tray_single_click_source)
            except Exception:
                pass
            self._tray_single_click_source = None

    def _run_pending_tray_single_click(self) -> bool:
        self._tray_single_click_source = None
        self._toggle_playback()
        return False

    def _schedule_tray_single_click(self) -> bool:
        self._cancel_tray_single_click()
        self._tray_single_click_source = GLib.timeout_add(260, self._run_pending_tray_single_click)
        return False

    def _install_own_tray_click_hooks(self) -> bool:
        icon = self._own_tray_icon
        if icon is None or self._own_tray_click_hooked:
            return False
        original = getattr(icon, '_on_notify', None)
        if original is None:
            return False

        WM_LBUTTONUP = 0x0202
        WM_LBUTTONDBLCLK = 0x0203
        WM_MBUTTONUP = 0x0208
        plugin = self

        def patched_notify(self_icon: Any, wparam: Any, lparam: Any) -> Any:
            try:
                event = int(lparam)
            except Exception:
                event = lparam
            if event == WM_LBUTTONUP:
                GLib.idle_add(plugin._schedule_tray_single_click)
                return 0
            if event == WM_LBUTTONDBLCLK:
                GLib.idle_add(plugin._cancel_tray_single_click)
                GLib.idle_add(plugin._copy_current_song_title)
                return 0
            if event == WM_MBUTTONUP:
                GLib.idle_add(plugin._copy_current_song_title)
                return 0
            return original(wparam, lparam)

        try:
            self._own_tray_notify_original = original
            icon._on_notify = types.MethodType(patched_notify, icon)
            self._own_tray_click_hooked = True
            return True
        except Exception:
            self._own_tray_notify_original = None
            self._own_tray_click_hooked = False
            log.debug('Could not install tray click hook', exc_info=True)
            return False

    def _restore_own_tray_click_hooks(self) -> None:
        self._cancel_tray_single_click()
        icon = self._own_tray_icon
        if icon is not None and self._own_tray_notify_original is not None:
            try:
                icon._on_notify = self._own_tray_notify_original
            except Exception:
                pass
        self._own_tray_notify_original = None
        self._own_tray_click_hooked = False

    def _refresh_own_tray_menu(self) -> None:
        if self._own_tray_icon is None:
            return
        try:
            self._own_tray_icon.title = 'Gadgim Gadget - %s - %s - Volume %d%%' % ('Playing' if self._player.is_playing else 'Stopped', self._display_name(), self._volume_percent())
            self._own_tray_icon.update_menu()
        except Exception:
            log.debug('Could not refresh separate tray menu', exc_info=True)

    def _remove_own_tray_icon(self) -> bool:
        self._stop_tray_meter()
        self._restore_own_tray_click_hooks()
        if self._own_tray_icon is not None:
            icon = self._own_tray_icon
            self._own_tray_icon = None
            try:
                icon.stop()
            except Exception:
                log.debug('Could not stop separate tray icon', exc_info=True)
        self._own_tray_thread = None
        self._refresh_native_pystray_menu()
        self._refresh_roster_button()
        return False

    def _show_own_tray_icon(self, *_args: Any) -> bool:
        self.config['create_own_tray_icon'] = True
        if self._own_tray_icon is not None:
            self._set_status(_('M3U tray icon is already visible'))
            self._refresh_everything()
            return False
        if self._install_own_tray_icon():
            self._set_status(_('M3U tray icon restored'))
        else:
            self._set_status(_('Could not restore M3U tray icon'))
        self._refresh_everything()
        return False

    def _toggle_own_tray_icon(self, *_args: Any) -> bool:
        if self._own_tray_icon is None:
            return self._show_own_tray_icon()
        self.config['create_own_tray_icon'] = False
        self._remove_own_tray_icon()
        self._set_status(_('M3U tray icon hidden'))
        self._refresh_everything()
        return False

    def _show_controller_window(self, message: str = '') -> bool:
        if self._controller_window is not None:
            self._controller_window.present()
            return False
        window = Gtk.Window(title=self._controller_window_title())
        window.set_default_size(500, 230)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)
        now_playing_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        outer.append(now_playing_box)
        self._station_label = Gtk.Label(label=self._display_name())
        self._station_label.set_xalign(0)
        now_playing_box.append(self._station_label)
        self._now_playing_label = Gtk.Label(label='')
        self._now_playing_label.set_xalign(0)
        self._now_playing_label.set_wrap(False)
        now_playing_box.append(self._now_playing_label)
        self._status_label = Gtk.Label(label=message or _('Stopped'))
        self._status_label.set_xalign(0)
        self._status_label.set_wrap(True)
        outer.append(self._status_label)
        self._details_label = Gtk.Label(label=self._last_install_details)
        self._details_label.set_xalign(0)
        self._details_label.set_wrap(True)
        outer.append(self._details_label)
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        outer.append(buttons)
        self._toggle_button = Gtk.Button(label=_('Play'))
        self._toggle_button.connect('clicked', lambda *_args: self._toggle_playback())
        buttons.append(self._toggle_button)
        self._copy_song_button = Gtk.Button(label=_('Copy song'))
        self._copy_song_button.set_tooltip_text(_('Copy current song title'))
        self._copy_song_button.connect('clicked', self._copy_current_song_title)
        buttons.append(self._copy_song_button)
        settings = Gtk.Button(label=_('Settings'))
        settings.connect('clicked', lambda *_args: self._show_settings_window())
        buttons.append(settings)
        diag = Gtk.Button(label=_('Diagnostics'))
        diag.connect('clicked', lambda *_args: self._show_diagnostics_window())
        buttons.append(diag)
        window.connect('close-request', self._on_window_close_request)
        self._controller_window = window
        self._refresh_labels()
        window.present()
        return False

    def _on_window_close_request(self, *_args: Any) -> bool:
        if self._controller_window is not None:
            self._controller_window.hide()
        return True

    def _remove_controller_window(self) -> None:
        if self._controller_window is not None:
            try:
                self._controller_window.destroy()
            except Exception:
                pass
        self._controller_window = None
        self._status_label = None
        self._toggle_button = None
        self._details_label = None
        self._station_label = None
        self._now_playing_label = None
        self._copy_song_button = None

    def _show_settings_window(self) -> bool:
        if self._settings_window is not None:
            self._settings_window.present()
            return False
        window = Gtk.Window(title=_('Gadgim Gadget Settings'))
        window.set_default_size(620, 420)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)
        help_label = Gtk.Label(label=_('Playlists: one per line, format: Name | M3U-or-stream-URL'))
        help_label.set_xalign(0)
        outer.append(help_label)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        outer.append(scrolled)
        view = Gtk.TextView()
        view.set_monospace(True)
        view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        view.get_buffer().set_text(str(self.config['playlists_text'] or DEFAULT_PLAYLISTS_TEXT))
        scrolled.set_child(view)
        self._settings_text_view = view
        buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        outer.append(buttons)
        save = Gtk.Button(label=_('Save playlists'))
        save.connect('clicked', lambda *_args: self._save_settings_window())
        buttons.append(save)
        import_btn = Gtk.Button(label=_('Import stations'))
        import_btn.set_tooltip_text(_('Import station list from a .gadgim-gadget, .gadget, or old .radio-gadget file'))
        import_btn.connect('clicked', self._import_playlists_config)
        buttons.append(import_btn)
        export = Gtk.Button(label=_('Export stations'))
        export.set_tooltip_text(_('Export station list to a .gadgim-gadget text configuration file'))
        export.connect('clicked', self._export_playlists_config)
        buttons.append(export)
        close = Gtk.Button(label=_('Close'))
        close.connect('clicked', lambda *_args: window.hide())
        buttons.append(close)
        window.connect('close-request', self._on_settings_close_request)
        self._settings_window = window
        window.present()
        return False

    def _save_settings_window(self) -> None:
        if self._settings_text_view is None:
            return
        buffer = self._settings_text_view.get_buffer()
        start = buffer.get_start_iter()
        end = buffer.get_end_iter()
        text = buffer.get_text(start, end, True).strip()
        if not text:
            text = DEFAULT_PLAYLISTS_TEXT
        self.config['playlists_text'] = text
        entries = self._playlist_entries()
        if self._current_playlist_index() >= len(entries):
            self.config['current_playlist_index'] = 0
        self._set_status(_('Playlists saved'))
        self._refresh_everything()

    def _current_settings_text(self) -> str:
        if self._settings_text_view is not None:
            buffer = self._settings_text_view.get_buffer()
            start = buffer.get_start_iter()
            end = buffer.get_end_iter()
            text = buffer.get_text(start, end, True).strip()
            if text:
                return text
        return str(self.config['playlists_text'] or DEFAULT_PLAYLISTS_TEXT).strip()

    def _export_playlists_config(self, *_args: Any) -> None:
        text = '# Gadgim Gadget station list\n# Format: Name | M3U-or-stream-URL\n\n%s\n' % self._current_settings_text()
        parent = self._settings_window if isinstance(self._settings_window, Gtk.Window) else None
        try:
            dialog = Gtk.FileChooserNative(
                title=_('Export Gadgim Gadget stations'),
                transient_for=parent,
                action=Gtk.FileChooserAction.SAVE,
                accept_label=_('Export'),
                cancel_label=_('Cancel'),
            )
            dialog.set_current_name('gadgim-stations.gadgim-gadget')
            if hasattr(dialog, 'set_do_overwrite_confirmation'):
                dialog.set_do_overwrite_confirmation(True)

            def on_response(dlg: Gtk.FileChooserNative, response: int) -> None:
                try:
                    if response == Gtk.ResponseType.ACCEPT:
                        file_obj = dlg.get_file()
                        path = file_obj.get_path() if file_obj is not None else ''
                        self._write_playlists_config_file(path, text)
                finally:
                    try:
                        dlg.destroy()
                    except Exception:
                        pass

            dialog.connect('response', on_response)
            dialog.show()
        except Exception:
            log.debug('Could not open export file chooser', exc_info=True)
            base = GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) or GLib.get_home_dir() or os.getcwd()
            path = os.path.join(base, 'gadgim-stations.gadgim-gadget')
            self._write_playlists_config_file(path, text)

    def _write_playlists_config_file(self, path: str, text: str) -> None:
        if not path:
            self._set_status(_('Export cancelled'))
            return
        if not path.lower().endswith(('.gadgim-gadget', '.gadget')):
            path += '.gadgim-gadget'
        try:
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(text)
            self._set_status(_('Stations exported: %s') % path)
        except Exception as error:
            log.debug('Could not export station list', exc_info=True)
            self._set_status(_('Could not export stations: %s') % error)

    def _import_playlists_config(self, *_args: Any) -> None:
        parent = self._settings_window if isinstance(self._settings_window, Gtk.Window) else None
        try:
            dialog = Gtk.FileChooserNative(
                title=_('Import Gadgim Gadget stations'),
                transient_for=parent,
                action=Gtk.FileChooserAction.OPEN,
                accept_label=_('Import'),
                cancel_label=_('Cancel'),
            )

            def on_response(dlg: Gtk.FileChooserNative, response: int) -> None:
                try:
                    if response == Gtk.ResponseType.ACCEPT:
                        file_obj = dlg.get_file()
                        path = file_obj.get_path() if file_obj is not None else ''
                        self._read_playlists_config_file(path)
                finally:
                    try:
                        dlg.destroy()
                    except Exception:
                        pass

            dialog.connect('response', on_response)
            dialog.show()
        except Exception as error:
            log.debug('Could not open import file chooser', exc_info=True)
            self._set_status(_('Could not open import dialog: %s') % error)

    def _read_playlists_config_file(self, path: str) -> None:
        if not path:
            self._set_status(_('Import cancelled'))
            return
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                raw = handle.read()
            lines = []
            for raw_line in raw.splitlines():
                line = raw_line.strip()
                if not line or line.startswith('#'):
                    continue
                lines.append(line)
            text = '\n'.join(lines).strip()
            if not text:
                self._set_status(_('Import file does not contain stations'))
                return
            self.config['playlists_text'] = text
            self.config['current_playlist_index'] = 0
            if self._settings_text_view is not None:
                self._settings_text_view.get_buffer().set_text(text)
            self._set_status(_('Stations imported: %s') % path)
            self._refresh_everything()
        except Exception as error:
            log.debug('Could not import station list', exc_info=True)
            self._set_status(_('Could not import stations: %s') % error)

    def _on_settings_close_request(self, *_args: Any) -> bool:
        if self._settings_window is not None:
            self._settings_window.hide()
        return True

    def _remove_settings_window(self) -> None:
        if self._settings_window is not None:
            try:
                self._settings_window.destroy()
            except Exception:
                pass
        self._settings_window = None
        self._settings_text_view = None

    def _show_diagnostics_window(self) -> bool:
        text = self._build_diagnostics()
        window = Gtk.Window(title=_('Gadgim Gadget Diagnostics'))
        window.set_default_size(720, 420)
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_top(12)
        outer.set_margin_bottom(12)
        outer.set_margin_start(12)
        outer.set_margin_end(12)
        window.set_child(outer)
        copy = Gtk.Button(label=_('Copy diagnostics'))
        copy.connect('clicked', lambda *_args: self._copy_to_clipboard(window, text))
        outer.append(copy)
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_vexpand(True)
        outer.append(scrolled)
        view = Gtk.TextView()
        view.set_editable(False)
        view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        view.get_buffer().set_text(text)
        scrolled.set_child(view)
        window.present()
        return False

    def _copy_to_clipboard(self, window: Gtk.Window, text: str) -> None:
        try:
            window.get_clipboard().set(text)
        except Exception:
            pass

    def _copy_current_song_title(self, *_args: Any) -> None:
        text = self._metadata_text.strip()
        if not text:
            self._set_status(_('No song title to copy yet'))
            return
        self._copy_text_with_status(text, _('Copied song title: %s'), _('Could not copy song title'))

    def _copy_text_with_status(self, text: str, ok_template: str, error_text: str) -> None:
        window = self._controller_window or self._settings_window
        if window is None:
            root = getattr(app, 'window', None)
            window = root if hasattr(root, 'get_clipboard') else None
        if window is None:
            self._set_status(error_text)
            return
        try:
            window.get_clipboard().set(text)
            self._set_status(ok_template % self._marquee_text(text, 52))
        except Exception:
            log.debug('Could not copy text to clipboard', exc_info=True)
            self._set_status(error_text)

    def _controller_window_title(self) -> str:
        base = 'Gadgim Gadget'
        if self._player.is_playing and self._metadata_text and self.config['show_now_playing']:
            return '%s  ♪  %s' % (base, self._marquee_text(self._metadata_text, 70))
        if self._player.is_playing:
            return '%s  ♪  %s' % (base, self._display_name())
        return base

    def _refresh_window_titles(self) -> None:
        self._refresh_controller_window_title()
        self._refresh_gajim_window_title()

    def _refresh_controller_window_title(self) -> None:
        if self._controller_window is None:
            return
        try:
            self._controller_window.set_title(self._controller_window_title())
        except Exception:
            log.debug('Could not update M3U controller window title', exc_info=True)

    def _refresh_gajim_window_title(self) -> None:
        window = getattr(app, 'window', None)
        if window is None or not hasattr(window, 'set_title'):
            return
        try:
            if self._main_window_title_original is None and hasattr(window, 'get_title'):
                self._main_window_title_original = window.get_title() or 'Gajim'
            base = self._main_window_title_original or 'Gajim'
            if self._player.is_playing and self._metadata_text and self.config['show_now_playing']:
                window.set_title('%s  ♪  %s' % (base, self._marquee_text(self._metadata_text, 70)))
            else:
                window.set_title(base)
        except Exception:
            log.debug('Could not update Gajim window title', exc_info=True)

    def _restore_window_titles(self) -> None:
        if self._controller_window is not None:
            try:
                self._controller_window.set_title('Gadgim Gadget')
            except Exception:
                pass
        window = getattr(app, 'window', None)
        if window is not None and hasattr(window, 'set_title') and self._main_window_title_original:
            try:
                window.set_title(self._main_window_title_original)
            except Exception:
                pass
        self._main_window_title_original = None
        self._volume_window = None
        self._volume_scale = None
        self._tray_single_click_source = None
        self._own_tray_notify_original = None
        self._own_tray_click_hooked = False

    def _build_diagnostics(self) -> str:
        icon = self._find_pystray_icon()
        lines = [
            'Gadgim Gadget v0.42 diagnostics',
            'install_details=%s' % self._last_install_details,
            'playing=%s' % self._player.is_playing,
            'backend=%s' % self._player.backend_name,
            'gst_audio_analysis=disabled',
            'tray_meter_mode=synthetic_strong_weak_weak',
            'tray_visual_interval_ms=%s' % self._tray_visual_interval_value(),
            'current_playlist=%s' % self._display_name(),
            'metadata=%s' % self._metadata_text,
            'publish_now_playing_status=%s' % self.config['publish_now_playing_status'],
            'last_published_status=%s' % self._last_published_status,
            'playlist_count=%s' % len(self._playlist_entries()),
            'app.app=%r' % getattr(app, 'app', None),
            'app.app.systray=%r' % getattr(getattr(app, 'app', None), 'systray', None),
            'found_pystray_icon=%r' % icon,
            'own_tray_icon=%r' % self._own_tray_icon,
            'own_tray_thread=%r' % self._own_tray_thread,
            'tray_meter_source=%r' % self._tray_meter_source,
            'tray_meter_running=%s' % (self._tray_meter_source is not None),
            'roster_widget=%r parent=%r' % (self._roster_widget, self._roster_widget_parent),
        ]
        if icon is not None:
            lines.append('icon_type=%s.%s' % (icon.__class__.__module__, icon.__class__.__name__))
            lines.append('icon_menu=%r' % getattr(icon, 'menu', None))
            lines.append('icon_visible=%r' % getattr(icon, 'visible', None))
        return '\n'.join(lines)

    def _refresh_labels(self) -> None:
        if self._toggle_button is not None:
            self._toggle_button.set_label(_('Stop') if self._player.is_playing else _('Play'))
        if self._details_label is not None:
            self._details_label.set_label(self._last_install_details)
        if self._station_label is not None:
            self._station_label.set_label(self._display_name())
        if self._now_playing_label is not None:
            if self._metadata_text and self.config['show_now_playing']:
                self._now_playing_label.set_label(_('Now playing: %s') % self._marquee_text(self._metadata_text, 52))
            else:
                self._now_playing_label.set_label(_('Now playing: no metadata yet') if self._player.is_playing else '')

    def _set_status(self, text: str) -> None:
        if self._status_label is not None:
            self._status_label.set_label(text)

    def _refresh_marquee(self) -> None:
        if self._player.is_playing and self._metadata_text and self.config['show_now_playing']:
            if self._marquee_source is None:
                self._marquee_source = GLib.timeout_add(700, self._tick_marquee)
        else:
            self._stop_marquee()

    def _tick_marquee(self) -> bool:
        if not self._player.is_playing or not self._metadata_text:
            self._marquee_source = None
            self._refresh_window_titles()
            return False
        self._marquee_offset += 1
        self._refresh_labels()
        self._refresh_roster_button()
        self._refresh_window_titles()
        return True

    def _stop_marquee(self) -> None:
        if self._marquee_source is not None:
            try:
                GLib.source_remove(self._marquee_source)
            except Exception:
                pass
            self._marquee_source = None
        self._refresh_window_titles()

    def _start_status_scroll(self) -> None:
        if not self.config['publish_now_playing_status']:
            return
        if not self._player.is_playing:
            return
        if self._status_scroll_source is None:
            interval = self._status_scroll_interval_seconds()
            self._status_scroll_source = GLib.timeout_add_seconds(interval, self._tick_status_scroll)
        self._publish_now_playing_status_once()

    def _stop_status_scroll(self, restore: bool = False) -> None:
        if self._status_scroll_source is not None:
            try:
                GLib.source_remove(self._status_scroll_source)
            except Exception:
                pass
            self._status_scroll_source = None
        self._status_scroll_offset = 0
        self._last_published_status = ''
        if restore and self.config['restore_status_on_stop']:
            self._restore_previous_status()

    def _tick_status_scroll(self) -> bool:
        if not self.config['publish_now_playing_status'] or not self._player.is_playing:
            self._status_scroll_source = None
            return False
        self._status_scroll_offset += 1
        self._publish_now_playing_status_once()
        return True

    def _publish_now_playing_status_once(self) -> None:
        if not self.config['publish_now_playing_status'] or not self._player.is_playing:
            return
        text = self._network_status_text()
        if not text or text == self._last_published_status:
            return
        if self._publish_status_message(text):
            self._last_published_status = text

    def _network_status_text(self) -> str:
        if self._metadata_text:
            base = '♪ %s — %s' % (self._display_name(), self._metadata_text)
        else:
            base = '♪ %s' % self._display_name()
        width = self._status_scroll_width_chars()
        if len(base) <= width:
            return base
        padded = base + '   •   '
        offset = self._status_scroll_offset % len(padded)
        return (padded + padded)[offset:offset + width]

    def _capture_previous_status(self) -> None:
        if self._previous_status_message is not None:
            return
        self._previous_status_message = self._get_global_status_message()
        self._previous_status_show = self._get_global_status_show()

    def _restore_previous_status(self) -> None:
        if self._previous_status_message is None:
            return
        message = self._previous_status_message or ''
        self._publish_status_message(message, show=self._previous_status_show)
        self._previous_status_message = None
        self._previous_status_show = None
        self._main_window_title_original = None
        self._volume_window = None
        self._volume_scale = None
        self._tray_single_click_source = None
        self._own_tray_notify_original = None
        self._own_tray_click_hooked = False

    def _publish_status_message(self, message: str, show: str | None = None) -> bool:
        # This updates your public XMPP presence status message. Gajim's API moved
        # across versions, so keep this deliberately defensive.
        gio_app = getattr(app, 'app', None)
        show_value = show or self._get_global_status_show() or 'online'
        candidates = []
        if gio_app is not None:
            candidates.append(getattr(gio_app, 'change_status', None))
            candidates.append(getattr(gio_app, '_change_status', None))
        for fn in candidates:
            if not callable(fn):
                continue
            for args in ((show_value, message), (show_value, message, False), (message,),):
                try:
                    fn(*args)
                    return True
                except TypeError:
                    continue
                except Exception:
                    log.debug('Could not publish radio status through %r', fn, exc_info=True)
                    break
        # Last-resort per-account attempt for older/newer internal APIs.
        try:
            clients = getattr(app, 'connections', None) or getattr(app, 'clients', None)
            if isinstance(clients, dict):
                ok = False
                for client in clients.values():
                    fn = getattr(client, 'change_status', None)
                    if callable(fn):
                        try:
                            fn(show_value, message)
                            ok = True
                        except Exception:
                            log.debug('Could not publish radio status through client', exc_info=True)
                return ok
        except Exception:
            pass
        return False

    def _get_global_status_message(self) -> str:
        try:
            from gajim.common.util import status as status_util
            fn = getattr(status_util, 'get_global_status_message', None)
            if callable(fn):
                value = fn()
                if value is not None:
                    return str(value)
        except Exception:
            pass
        try:
            settings = getattr(app, 'settings', None)
            if settings is not None:
                for key in ('statusmsg', 'status_message', 'global_status_message'):
                    try:
                        value = settings.get_app_setting(key)
                        if value is not None:
                            return str(value)
                    except Exception:
                        pass
        except Exception:
            pass
        return ''

    def _get_global_status_show(self) -> str:
        for value in self._status_show_candidates():
            if value:
                return value
        return 'online'

    def _status_show_candidates(self) -> list[str]:
        values: list[str] = []
        try:
            from gajim.common.util import status as status_util
            for name in ('get_global_status', 'get_global_show', 'get_status'):
                fn = getattr(status_util, name, None)
                if callable(fn):
                    try:
                        values.append(str(fn()))
                    except Exception:
                        pass
        except Exception:
            pass
        try:
            settings = getattr(app, 'settings', None)
            if settings is not None:
                for key in ('status', 'global_status', 'show'):
                    try:
                        value = settings.get_app_setting(key)
                        if value is not None:
                            values.append(str(value))
                    except Exception:
                        pass
        except Exception:
            pass
        allowed = {'online', 'chat', 'away', 'xa', 'dnd', 'invisible', 'offline'}
        return [value for value in values if value in allowed]

    def _status_scroll_width_chars(self) -> int:
        try:
            value = int(self.config['status_scroll_width'])
        except Exception:
            value = 64
        return max(24, min(value, 120))

    def _status_scroll_interval_seconds(self) -> int:
        try:
            value = int(self.config['status_scroll_interval'])
        except Exception:
            value = 6
        return max(4, min(value, 60))

    def _marquee_text(self, text: str, width: int) -> str:
        if len(text) <= width:
            return text
        padded = text + '   •   '
        offset = self._marquee_offset % len(padded)
        doubled = padded + padded
        return doubled[offset:offset + width]

    def _playlist_entries(self) -> list[PlaylistEntry]:
        raw = str(self._cfg('playlists_text', '') or '').strip()
        entries: list[PlaylistEntry] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '|' in line:
                name, url = line.split('|', 1)
            elif ',' in line:
                name, url = line.split(',', 1)
            else:
                name, url = '', line
            name = name.strip()
            url = url.strip()
            if not url:
                continue
            if not name:
                name = url
            entries.append(PlaylistEntry(name=name, url=url))
        if not entries:
            name = str(self._cfg('display_name', DEFAULT_NAME)).strip() or DEFAULT_NAME
            url = str(self._cfg('playlist_url', DEFAULT_PLAYLIST_URL)).strip() or DEFAULT_PLAYLIST_URL
            entries.append(PlaylistEntry(name=name, url=url))
        return entries

    def _current_playlist_index(self) -> int:
        try:
            index = int(self._cfg('current_playlist_index', 0))
        except Exception:
            index = 0
        entries = self._playlist_entries()
        if not entries:
            return 0
        return max(0, min(index, len(entries) - 1))

    def _current_playlist(self) -> PlaylistEntry:
        entries = self._playlist_entries()
        return entries[self._current_playlist_index()]

    def _display_name(self) -> str:
        try:
            return self._current_playlist().name or DEFAULT_NAME
        except Exception:
            return str(self._cfg('display_name', DEFAULT_NAME)).strip() or DEFAULT_NAME


    def _cfg(self, key: str, default: Any = None) -> Any:
        try:
            return self.config[key]
        except Exception:
            return default

    @staticmethod
    def _get_gio_application() -> Any | None:
        for candidate in (getattr(app, 'app', None), getattr(app, 'window', None)):
            if candidate is None:
                continue
            if hasattr(candidate, 'add_action'):
                return candidate
            if hasattr(candidate, 'get_application'):
                try:
                    application = candidate.get_application()
                    if application is not None and hasattr(application, 'add_action'):
                        return application
                except Exception:
                    pass
        return None
